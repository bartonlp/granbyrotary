<?php
require_once("/home/bartonlp/includes/granbyrotary.conf");
$S = new GranbyRotary();  // not header etc.

// Does the file exist already?

if(empty($_GET['article'])) {
  echo "Must have an article<br>";
  exit(1);
}

$id = $_GET['article'];
$articleFile = "/tmp/article.$id.php";

// Use the tinyButStrong template class. It can do a lot more than
// what we need, but it can do what we need so why not.

// Use new version 
require_once("/home/bartonlp/bartonphillips.com/htdocs/tbs_class/tbs_class_php5.php");
$TBS = new clsTinyButStrong ;

// article.php takes the following args:
// article= article 'id' in database
// ...

// Now read in the article file

$results = $S->query("select * from articles where id='$id'");

$row = mysql_fetch_assoc($results);

if(empty($row)) {
  echo "Article Not Found on Server<br>\n";
  exit(1);
}

extract($row);

// Now update the count for this article

if($S->id) {
  $S->query("insert into articlecnt (id, memberId, count) values('$id', '$S->id', 1)
on duplicate key update count=count+1");
} else {
  try {
    $agent = $_SERVER['HTTP_USER_AGENT'];
    $ip = $_SERVER['REMOTE_ADDR'];

    $query = "insert into articlecntnonmbrs (id, ip, agent, count) values('$id', '$ip', '$agent', 1)
on duplicate key update count=count+1";
    
    $S->query($query);
  } catch(SqlException $e) {
    // ER_NO_SUCH_TABLE == 1146

    if($e->getCode() == 1146) {
      // If table does not exist create it
        
      $query2 = <<<EOF
CREATE TABLE `articlecntnonmbrs` (
  `id` int(11) NOT NULL,
  `ip` varchar(20) NOT NULL,
  `agent` varchar(255) NOT NULL,
  `count` int default 1,
  `lasttime` timestamp,
  PRIMARY KEY  (`id`, `ip`, `agent`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
EOF;
      $S->query($query2);
      $S->query($query);
    } else {
      // Any other error just rethow the exception
      $ex = "IP=$ip, Agent=$agent: Original Message=". $e->getMessage();
      throw(new SqlException($ex));
    }
  }
}

// Default template file

$template= "template.default.template";

// Did we find a 'articleTemplate'?

if(!empty($articletemplate)) {
  $template=$articletemplate;
}

// Load the template

$TBS->LoadTemplate($template);

// Fill in the fields

$title = empty($name) ? "News Article $id" : "$name";
$mainTitle = "$title<br>$created";
$body = "";

switch($articleInclude) {
  case "rss":
    $body = $rssfeed;
    break;
  case "article";
    $body = $article;
    break;
  case "both";
    $body = "$rssfeed\n$article";
    break;
}

$TBS->MergeField('title', $title); // just a place holder
$TBS->MergeField('header', $header);
$TBS->MergeField('headertitle', "<h2>$mainTitle</h2>"); // Just a place holder
$TBS->MergeField('body', $body);

// Generate the filled in template but do not display it or exit!

$TBS->Show(TBS_NOTHING);

// Get the filled in code for the page.

$results = $TBS->Source;

// Create a file to hold the preview

$f = fopen($articleFile, "w");

fwrite($f, $results);

fclose($f);

chmod ($articleFile, 0666);

// Now call ourself with the 'show' flag set!

include($articleFile);
//header("Location: http://www.granbyrotary.org/articles/article.$id");

unlink($articleFile);
?>

