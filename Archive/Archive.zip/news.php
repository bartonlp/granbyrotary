<?php
require_once("/home/bartonlp/includes/granbyrotary.conf");

$S = new GranbyRotary;
$S->lookedAtNews();

$page = "";
$hdr = "";

  // Read news from database
  
$results = $S->query("select article, rssfeed, articleInclude, created, expired, header, 
left(created, 10) as creat, left(expired, 10) as exp from articles where expired > now() order by pageorder, created desc");

while($row = mysql_fetch_assoc($results)) {
  extract($row);
  switch($articleInclude ) {
    case "article":
      $story = $article;
      break;
    case "rss":
      $story = $rssfeed;
      break;
    case "both":
      $story = "$rssfeed\n$article";
      break;
  }
  if($exp == "2020-01-01") {
    $exp = "NEVER";
  }
    
  $page .= <<<EOF
<div>
$story 
</div>
<p style="color: brown; font-size: 10px; font-style: italic">Creation date: $creat, Expires: $exp</p>

<hr>

EOF;

  $hdr .= "$header";
}
$f = fopen("/tmp/newspage.i.php", "w");
fwrite($f, $page);
fclose($f);

echo <<<EOF
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
   <title>Club News</title>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
   <meta name="Author" content="Barton L. Phillips, mailto:barton@granbyrotary.org">
   <meta name="description"
      content="Name: Rotary Club of Granby Colorado, Page: Club News">
   <meta name="keywords" content="rotary">

   <!-- RSS FEED -->
   <link rel="alternate" type="application/rss+xml" title="RSS"
        href="/rssfeed.xml">

   <!-- Link our custom CSS -->
   <link rel="stylesheet" title="Rotary Style Sheet"
        href="/css/rotary.css" type="text/css">

   <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.0/jquery.min.js"></script>
 <!--  <script type='text/javascript' src='/js/jquery-1.3.2.min.js'></script> -->

   <!-- for McArthur quote in old news stuff at bottom of page -->
   <script type='text/javascript'>

jQuery(document).ready(function($) {
  
  $("#quote").hover(function(e) {
    var w = e.pageX;
    if(e.pageX + $("#mcarthur").width() > $(document).width()) {
      w = $(document).width() - $("#mcarthur").width() -45;
    }
    $("#mcarthur").css({top : e.pageY + 20, left : w}).show()
  }, function() {
    $("#mcarthur").hide();
  });
});
   </script>

   <style type="text/css">
#mcarthur {
        display: none;
        position: absolute;
        width: 400px;
        padding: 5px;

        background-color: white;
}
   </style>

<?php
echo "$hdr";
</head>
<body>

EOF;

$date = date("l F Y");   

if($S->GetId() != 0) {
  // Show Info for MEMBERS
  
  $greet = "<h2>News<br>$date<br>Welcome $S->GrUser</h2>";

} else {
  $greet = <<<EOF
<h2>News<br>$date</h2>
<h2>More to see on the web site if you <a href='/login.php?return=/news.php'>login</a></h2>
<p>Not a Grand County Rotarian? You can <b>Register</b> as a visitor.
<a href="/login.php?return=$_SERVER[PHP_SELF]&visitor=1">Register</a></p>

<p>If you are a member take this time to <a href='/login.php'>login</a>, it is easy.
   All you need is the email address you gave the club.
   After you login click on the <b>User Profile</p> item in the navigation menu above.
   You can add a seperate password, update your email
   address, phone number, and home address.
</p>

EOF;
}
  
echo $S->getBanner("$greet");

include("upcomingmeetings.php");

include("/tmp/newspage.i.php");

?>

<!-- OLD NEWS -->

<h2>Older News</h2>
<p>After a while news becomes somewhat <b>Old</b> and while it is no
   longer current you may still be interested in reading older news
   items. You can do that at the <a href='/oldnews.php'>Old News
      Page</a> where we keep that good old stuff for quite a while. Of
   course at some point everything either becomes <i>New
      Again</i> or just <i>Fades away</i> like old soldiers who
   <i>Never Die</i>. Well unlike
   <a id="quote" href='http://en.wikipedia.org/wiki/Douglas_MacArthur'>McArthur</a>
   after a while the old news will just vanish!</p>

<!-- Quote from General Duglas McArthur, not displayed until we hover
over his name above -->
<div id='mcarthur'>&quot;Old soldiers never die; they just fade away... And like the
   old soldier of that ballad, I now close my military career and
   just fade away an old soldier who tried to do his duty as God
   gave him the light to see that duty. Good-by&quot;
</div>

<hr>

<!-- Granby Rotary News Letter from Patric -->

<a name="newsletters"></a>

<!--
<h2><a href='/newsletters/latest.php'>October 8 Granby Rotary News
   Letter</a></h2>
-->

<h2><a href="/oldnewsletters.php">Old News Letters</a></h2>

<hr>

<?php
echo $S->getFooter();

unlink("/tmp/newspage.i.php");
?>
