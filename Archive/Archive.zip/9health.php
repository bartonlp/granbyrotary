<?php
// <start> Standard Start Stuff 
require_once("tbs_class.php");
$TBS = new clsTinyButStrong ;

require_once("rotary.i.php");
$gr = new GranbyRotary;

// Add Page Title for header here

$pageTitle = <<<EOL
<h2>9Health Fair Volunteer Opertunities</h2>
EOL;

// make header and footer strings

$hdr = $gr->getHeader($pageTitle);
$ftr = $gr->getFooter();

// Add Style for page here

$style=<<<EOL
li:first-line {
   font-weight: bold;
}
li p {
   margin-top: 0;
   margin-bottom: 0;
   padding-left: 1em;
   font-style: italic;
}
EOL;

// Add Script for page here

$script=<<<EOL
EOL;

$tbsFile = 'template/template.tbs';  // add file name here
$TBS->LoadTemplate($tbsFile);

// <title>
$title = 'Granby Rotary 9HealthFair';
// <meta description=...>
$metadesc = 'Name: Rotary Club of Granby Colorado, Page: 9HealthFair';
// <meta keywords>
// $keywords='...'

// Merge header and footer  
$TBS->MergeField('header',$hdr);
$TBS->MergeField('footer',$ftr);

// </start> end of standard stuff

// START OF CUSTOM PAGE STUFF
// example Merge stuff
//$caption = array('page'=>'Page', 'id'=>'Id', 'agent'=>'Agent', 'count'=>'Count', 'time'=>'Last Time');
//$TBS->MergeBlock('top', $caption);
//$TBS->MergeBlock('membercnt', $gr->getDb(), 'select * from memberpagecnt order by page');

function loadFile($s) {
  $pre = basename($_SERVER[PHP_SELF], '.php');
  $file = "${pre}.${s}.txt";
  if(file_exists($file)) {
    $data = file_get_contents($file);
  }
  return $data;
}

$TBS->MergeField('body', 'loadFile', true);
$bodyscript = '';

// Show the page
$TBS->Show();
?>

