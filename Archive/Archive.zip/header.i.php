<?php
echo <<<EOF
<head>
  <title>$headTitle</title>
  <meta name="description"
     content="Name: Rotary Club of Granby Colorado, Page: $headTitle" />
  <meta name="keywords" content="rotary" />

  <!-- Link our custom CSS -->
  <link rel="stylesheet" title="Rotary Style Sheet" href="/rotary.css" type="text/css">

  <!-- Include the jQuery as a default -->
  <script type='text/javascript' src='/js/jquery-1.3.2.min.js'></script>

  <!-- Script for this page -->
  <!-- Styles for this page -->

EOF;
?>