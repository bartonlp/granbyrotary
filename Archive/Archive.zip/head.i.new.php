<?php
// Head section for Granby Rotary

echo $S->getPageHead($HeadTitle, $HeadTitle);
  

?>