<?php

echo <<<EOF
<head>
  <title>$HeadTitle</title>

  <!-- METAs -->
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="copyright" content="2009-2010, Rotary Club of Granby Colorado" />
  <meta name="Author" content="Barton L. Phillips, mailto:barton@granbyrotary.org"/>
  <meta name="description" content="$HeadDesc"/>
  <meta name="keywords" content="Rotary, Granby, Grand County, Colorado, Grand County All-Club Email"/>

  <!-- Microsoft verification tag -->
  <meta name="msvalidate.01" content="769E2BFA62FFED5C91B7F4200CECA90A" />
  <!-- Google verification tag -->
  <meta name="google-site-verification" content="FtWTx_Hn0ie5lTF42jPm5zjVtsDtBFC1MC7kyDJ99AU" />
  <meta name="verify-v1" content="dgAIXuJJft+YWGYjqA2g/NbkCkbfkMdqtAjtx3E4nkc="/>

  <!-- FAVICON.ICO -->
  <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
   
  <!-- RSS FEED -->
  <link href="http://feeds2.feedburner.com/http/wwwgranbyrotaryorg"
       title="Subscribe to my feed"
         rel="alternate"
        type="application/rss+xml" />
   
  <!-- Link our custom CSS -->
  <link rel="stylesheet" title="Rotary Style Sheet" href="/css/rotary.css" type="text/css"/>

  <!-- jQuery -->
  <script type="text/javascript" src="/js/jquery-1.3.2.min.js"></script>

  <!-- Script for this page -->
  <!-- Styles for this page -->

</head>

EOF;

?>