<?php
require_once("/home/bartonlp/includes/granbyrotary.conf");
$gr = new GranbyRotary;
?>
<head>
   <title>Club Members Directory</title>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
   <meta name="Author"
      content="Barton L. Phillips, mailto:barton@granbyrotary.org"/>
   <meta name="description"
      content="Name: Rotary Club of Granby Colorado, Page: Members Directory"/>
   <meta name="keywords" content="rotary"/>

   <!-- Link our custom CSS -->
   <link rel="stylesheet" title="Rotary Style Sheet"
        href="/css/rotary.css" type="text/css"/>

   <!-- jQuery -->
   <script type="text/javascript" src="/js/jquery-1.3.2.min.js"></script>

<script type='text/javascript'>
$(document).ready(function() {
  $(".select").show();
  
  $("#selectAll").click( function() {
    $("input[type='checkbox']").attr("checked","true");
  });
  $("#selectNone").click( function() {
    $("input[type='checkbox']").removeAttr("checked");
  });

  // Add or remove members from individual catagouries
  
  $("#selectAllMem").click( function() {
    // 'this' is the span we clicked
    // The parent is the 'p' the span is in.
    // next gets us to the 'p' with the input
    // Then we do what we did above with all.
    $(this).parent().next().find("input[type='checkbox']").attr("checked","true");
  });
  $("#selectNoneMem").click( function() {
    $(this).parent().next().find("input[type='checkbox']").removeAttr("checked");
  });

  $("#selectAllInact").click( function() {
    $(this).parent().next().find("input[type='checkbox']").attr("checked","true");
  });
  $("#selectNoneInact").click( function() {
    $(this).parent().next().find("input[type='checkbox']").removeAttr("checked");
  });
  
  $("#selectAllHon").click( function() {
    $(this).parent().next().find("input[type='checkbox']").attr("checked","true");
  });
  $("#selectNoneHon").click( function() {
    $(this).parent().next().find("input[type='checkbox']").removeAttr("checked");
  });
  
  $("#selectAllVis").click( function() {
    $(this).parent().next().find("input[type='checkbox']").attr("checked","true");
  });
  $("#selectNoneVis").click( function() {
    $(this).parent().next().find("input[type='checkbox']").removeAttr("checked");
  });
  
  $("#selectAllOther").click( function() {
    $(this).parent().next().find("input[type='checkbox']").attr("checked","true");
  });
  $("#selectNoneOther").click( function() {
    $(this).parent().next().find("input[type='checkbox']").removeAttr("checked");
  });

  $("#child").hide();
  
  $("#parent").toggle(function() {
    $("#child").show();
  }, function() {
    $("#child").hide();
  });
  
});
</script>  
   
   <!-- Styles for this page only -->
   <style type='text/css'>
#loginMsg {
        text-align: center;
}
#loginMsg a {
        font-variant: small-caps;
        font-size: x-large;
}
#parent {
        border: 4px outset gray;
        color: white;
        position: relative;
        top: -10px;
        padding-right: 1em;
        padding-left: 1em;
        background-color: red;
}
#child {
        display: inline;
}
#child a {
        border: 1px solid black;
        display: block;
        padding: 2px 5px;
        background-color: white; /* #FFFFEE; */
}        

#todayGuests, #todayGuests * {
        background-color: white;
        border: 1px solid black;
}
#todayGuests * {
        padding: 5px;
}
   </style>

</head>

<body>

<?php
$gr->header("<h2><i>All-Club</i> Grand County Rotary Members</h2>");

// Check if we have a user ID. If yes then let this user edit his
// contact information.

if($gr->id != 0) {
  echo <<<EOF
<div style='width: 400px; margin-left: auto; margin-right: auto; text-align: center;'>
<p>Welcome $gr->GrUser</p>

<span id='parent'>Members Features</span>
<div id='child'>
   <a href='/edituserinfo.php'>Edit Your User Profile</a>
   <a href='/hits.php'>Web Site Statistics</a>
EOF;

  if($gr->id == ID_BARTON) {
    echo <<<EOF
<a href='/admin/admin.php'>ADMINISTER DATABASE</a>
<a href='/articles/admin.php'>ADMINISTER ARTICLES</a>
<a href='/articles/adminrss.php'>ADMINISTER RSS</a>
<a href='/articles/createarticle.php'>Create New Article</a>
EOF;
  }

  $whos = $gr->getWhosBeenHereToday();

  echo <<<EOF
</div>
</div>

<hr/>

<div style='float: right; margin-right: 50px'>
$whos
</div>

EOF;
} else {
  // NO ID YET

  echo <<<EOF
<h3 id='loginMsg'>If you are a Grand County Rotarian please <a href='/login.php?return=$_SERVER[PHP_SELF]'>Login</a> at this time.<br/>
There is a lot more to see if you <a href='/login.php?return=$_SERVER[PHP_SELF]'>Login</a>!
</h3>
<p style='text-align: center'>Not a Grand County Rotarian? You can <b>Register</b> as a visitor.
<a href="/login.php?return=$_SERVER[PHP_SELF]&visitor=1">Register</a></p>
<hr/>
EOF;

}

echo <<<EOF
<p style='border: 1px solid black; display: table-cell; padding: 15px'>
<span style='color: red'>To send an email to the member click on his
   <b style='color: blue;'>Name</b></span>.

EOF;

if(!empty($gr->id)) {
  echo <<<EOF
<br/>Or to send multiple emails check the names and use<br/>
the button at the bottom to submit the list.<br/>

Select: <span id='selectAll' class='select' style='color: blue; display: none'>All</span>,
<span id='selectNone' class='select' style='color: blue; display: none'>None</span>

EOF;

}

echo "</p>";

// Get all Active Members
// Active members

$result = $gr->query("select * from rotarymembers where status='active' order by LName");

// How many Active members do we have

$cnt = mysql_num_rows($result);

// Form for multiple emails

if(!empty($gr->id)) {
   print("<form action='/multmail.php' method='post'>\n");
}

echo <<<EOF
<p>Granby Rotary Active Members ($cnt):<br/>
Name (Office)<br/>
Select Members: <span id='selectAllMem' class='select' style='color: blue; display: none'>All</span>,
<span id='selectNoneMem' class='select' style='color: blue; display: none'>None</span>
</p>

<p>
EOF;

while($row = mysql_fetch_array($result)) {
  $officer = !empty($row[office]) ? " ($row[office])" : "";

  $checkbox = '';

  if(!empty($gr->id)) {
     $checkbox = "<input type=checkbox name=Name[] value='$row[id]'>";
  } 

  print("$checkbox<a href='email.php?id=$row[id]'>$row[FName] $row[LName]</a>$officer<br/>\n");
}

// Honorary Members

$result = $gr->query("select * from rotarymembers where status='honorary' order by LName");

// How many Active members do we have

$cnt = mysql_num_rows($result);

echo <<<EOF
</p>
<hr/>
<p>Granby Rotary Honorary Members ($cnt):<br/>
Name<br/>
Select Honorary Members: <span id='selectAllHon' class='select' style='color: blue; display: none'>All</span>,
<span id='selectNoneHon' class='select' style='color: blue; display: none'>None</span>
</p>

<p>
EOF;

while($row = mysql_fetch_array($result)) {
  $checkbox = '';

  if(!empty($gr->id)) {
     $checkbox = "<input type=checkbox name=Name[] value='$row[id]'>";
  } 

  print("$checkbox<a href='email.php?id=$row[id]'>$row[FName] $row[LName]</a><br/>\n");
}

// Now get Inactive members
// Inactive members have a status=1

$result = $gr->query("select * from rotarymembers where status='inactive' order by LName");

$cnt = mysql_num_rows($result);

if($cnt != 0) {
  echo <<<EOF
</p>
<hr/>
<p>Granby Rotary: Inactive members ($cnt):<br/>
Select Inactive Members: <span id='selectAllInact' class='select' style='color: blue; display: none'>All</span>,
<span id='selectNoneInact' class='select' style='color: blue; display: none'>None</span>
</p>

<p>
EOF;

  while($row = mysql_fetch_array($result)) {
    $checkbox = '';

    if(!empty($gr->id)) {
       $checkbox = "<input type=checkbox name=Name[] value='$row[id]'>";
    } 

    print("$checkbox<a href='email.php?id=$row[0]'>$row[1] $row[2]</a><br/>\n");
  }
}

// Now get Visiters
// visitors have a status='visitor'

$result = $gr->query("select id, FName, LName, club from rotarymembers where status='visitor' order by LName");

$cnt = mysql_num_rows($result);

if($cnt != 0) {
  echo <<<EOF
</p>
<hr/>
<p>Granby Rotary or Web Site Visitors ($cnt):<br/>
Name (Club)<br/>
Select Visitors: <span id='selectAllVis' class='select' style='color: blue; display: none'>All</span>,
<span id='selectNoneVis' class='select' style='color: blue; display: none'>None</span>
</p>

<p>
EOF;

  while($row = mysql_fetch_array($result)) {
    if(!empty($row[3])) {
      $club = " ($row[3])";
    } else {
      $club = '';
    }
    $checkbox = '';

    if(!empty($gr->id)) {
       $checkbox = "<input type=checkbox name=Name[] value='$row[id]'>";
    } 

    print("$checkbox<a href='email.php?id=$row[0]'>$row[1] $row[2]</a>$club<br/>\n");
  }
}

// Now get Other Clubs
// visitors have a status=otherclub

$result = $gr->query("select id, FName, LName, club, otherclub from rotarymembers where status='otherclub' order by otherclub,LName");

$cnt = mysql_num_rows($result);

$clubName = array( granby => "Granby", grandlake => "Grand Lake", kremmling => "Kremmling", winterpark => "Winter Park/Fraser");

if($cnt != 0) {
  echo <<<EOF
</p>
<hr/>
<p>Members From Grand Lake, Kremmling, and Winter Park/Fraser Clubs ($cnt):<br/>
Name (Club)<br/>
Select Other Club Members: <span id='selectAllOther' class='select' style='color: blue; display: none'>All</span>,
<span id='selectNoneOther' class='select' style='color: blue; display: none'>None</span>
</p>

<p>
EOF;

  while($row = mysql_fetch_array($result)) {
    if(!empty($row[3])) {
      $club = " ($row[3])";
    } else {
      $club = '';
    }
    $checkbox = '';

    if(!empty($gr->id)) {
       $checkbox = "<input type=checkbox name=Name[] value='$row[id]'>";
    } 

    print("$checkbox<a href='email.php?id=$row[0]'>$row[1] $row[2]</a>$club<br/>\n");
  }
}

if(!empty($gr->id)) {
   echo <<<EOF
<br/><input type='submit' value='Send Emails'>
</form>
</p>

<h3><a href="/showemailsent.php">Review Emails You Sent</a></h3>

EOF;
}
?>

<hr/>
<div class='blkcenter'>
<?php
$wc3val = <<<EOF
<!-- WC3 Validation for XHTML -->
<p>
   <a href="http://validator.w3.org/check?uri=referer"><img
   src="/images/valid-xhtml10.png"
   alt="Valid XHTML 1.0 Strict"
   style='height: 31px; width: 88px; border: 0'/></a>

   <a href="http://jigsaw.w3.org/css-validator/check/referer">
      <img style="border:0;width:88px;height:31px"
             src="http://jigsaw.w3.org/css-validator/images/vcss"
             alt="Valid CSS!" />
   </a>
</p>
EOF;
$gr->footer($wc3val);
?>
</div>


</body>
</html>
