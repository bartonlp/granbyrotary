<?php
require_once("/home/bartonlp/includes/granbyrotary.conf");
$G = new GranbyRotary;
$self = $_SERVER['PHP_SELF'];
?>
<head>
   <title>Lunch Survey Results</title>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
   <meta name="Author"
      content="Barton L. Phillips, mailto:barton@granbyrotary.org"/>
   <meta name="description"
      content="Name: Rotary Club of Granby Colorado, Page: Meeting Programs"/>
   <meta name="keywords" content="rotary"/>

   <!-- Link our custom CSS -->
   <link id="defaultcss" rel="stylesheet" title="Rotary Style Sheet"
        href="/css/rotary.css" type="text/css" media="screen" />
   <!-- jQuery -->
   <script type="text/javascript" src="/js/jquery-1.3.2.min.js"></script>

   <style type='text/css'>
   </style>

</head>

<body>
<?php
$G->header("<h1>Lunch Survey Results</h1>");

echo <<<EOF
<table border="1">
<thead>
<tr><th>Name</th><th>Choice</th><th>Other</th></tr>
</thead>
<tbody>

EOF;

$result = $G->query("select concat(fname, ' ', lname) as name, vote, other from lunchsurvey as l
left join rotarymembers as r on l.id=r.id");

while($row = mysql_fetch_assoc($result)) {
  extract($row);
  echo <<<EOF
<tr><td>$name</td><td>$vote</td><td>$other</td></tr>

EOF;
}

echo <<<EOF
</tbody>
</table>
<br/>
<a href="/">Go To Welcome Page</a>

EOF;
$G->footer();
?>