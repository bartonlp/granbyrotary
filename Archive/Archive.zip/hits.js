// hits.js for /hits.php

jQuery(document).ready(function($) {
  $("h2.table").each(function() {
    $(this).append(" <span class='showhide' style='color: red'>Show Table</span>");
  });

  $("div.table").hide();
  
  $(".showhide").css("cursor", "pointer");

  $(".showhide").toggle(function() {
    $(this).parent().next().show(); // This is <span class="showhide", the parent is the h2, next is the div with the table
    $(this).text("Hide Table");
  }, function() {
    $(this).parent().next().hide();
    $(this).text("Show Table");
  });

  $("table").not("#hitCountertbl").addClass('tablesorter'); // attach class tablesorter to all except our counter
  $("#memberHits, #otherMemberHits, #memberNot").tablesorter();
  $("#pageHits").tablesorter({ sortList:[[1,1]] });
  $("#ipHits").tablesorter({sortList:[[2,1]] });
  $("#ipAgentHits").tablesorter({ sortList:[[4,1]] });
  $("#agentHits").tablesorter({ sortList:[[1,1]] });
  $("#lamphost table").tablesorter({ sortList: [[2,1]], headers: { 1: {sorter: "currency"} } } );
  $("#OScnt table").tablesorter({ sortList:[[1,1]] , headers: { 1: {sorter: "currency"}, 2: {sorter: "currency"}}});
  $("#browserCnt table").tablesorter({ sortList:[[1,1]], headers: { 1: {sorter: "currency"}, 2: {sorter: "currency"}} });
  $("#ajaxRobots table").tablesorter({ sortList:[[2,1]] });

  // Set up the Ip Agent Hits table
  $("#ipAgentHits").before("<p>You can toggle the display of only members or all visitors \
  <input type='submit' value='Show/Hide NonMembers' id='hideShowNonMembers' /><br/> \
    You can toggle the display of the ID \
    <input type='submit' value='Show/Hide ID' id='hideShowIdField' /><br/> \
    Your can taggle the display of the Webmaster \
    <input type='submit' value='Show/Hide Webmaster' id='hideShowWebmaster' /> \
    <p id='botmsg' style='color: blue;visibility: hidden'>Bots are blue</p>");

  // Set up Ip Hits
  $("#ipHits").before("<p>Move the mouse over ID to see the member&apos;s name.<br/> \
  Click to toggle <i>all</i> or <i>members-only</i> \
  <input id='membersonly' type='submit' value='toggle all/members-only' /></p>");

  // create a div for name popup
  $("body").append("<div id='popup' style='position: absolute; display: none; border: 2px solid black; background-color: #8dbdd8; padding: 5px;'></div>");

  $("#ipHits tbody tr td:nth-child(2)").hover(function(e) {
    var name = "Non Member";
    if($(this).text() != '0') {
      name =$("#Id_"+$(this).text()).text();
    }
    $("#popup").text(name).css({ top: e.pageY+20, left: e.pageX }).show();
  }, function() {
    $("#popup").hide();
  });

  // Hide and mark all IDs that are zero in the Ip Hits table
  $("#ipHits tbody tr td:nth-child(2)").each(function() {
    var $this = $(this);
    if($this.text() == '0') $this.parent().addClass('ipHitsNoId').hide();
  });

  // Members only button toggles members and all in Ip Hits table
  $("#membersonly").toggle(function() {
    $(".ipHitsNoId").show();
  }, function() {
    $(".ipHitsNoId").hide();
  });

  // Ip Agent Hits.
  // Hide all ids of zero
  
  $(".noId").hide();

  // Button to toggle between all and members only in Ip Agent Hits
  // table
  $("#hideShowNonMembers").toggle(function() {
    $(".noId").not("[name='blp']").show();
    $("#botmsg").css("visibility", "visible");
  }, function() {
    $(".noId").hide();
    $("#botmsg").css("visibility", "hidden");
  });

  // Hide the ID field in Ip Agent Hits table
  $(".agentId").hide();

  // Button to toggle between no ID and showing ID in Ip Agent Hits
  // table
  $("#hideShowIdField").toggle(function() {
    $(".agentId").show();
  }, function() {
    $(".agentId").hide();
  });

  // Hide the webmaster (me) in the Ip Agent Hits table
  $(".blp").hide();

  // Button to toggle between hide and show of Webmaster in Ip Agents
  // Hits Table
  $("#hideShowWebmaster").toggle(function() {
    $(".blp").show();
  }, function() {
    $(".blp").hide();
  });
});