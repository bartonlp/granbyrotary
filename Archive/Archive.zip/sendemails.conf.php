<?php
// This is the file that should be modified to your site requirements. The file sendemails.i.php should not be modified

$DEBUG = 0; // To get debug output and not send email set this to true
$self = $_SERVER['PHP_SELF'];

// Set the global title and description in the <head> section. These can be changed on a per page bases by adding logic to the
// PageNInit() function to do a preg_replace("|<title>.*?</title>|s", "<title>$newtitle</title>", $PageHead); and the same for
// the <meta name="description" content="$HeadDesc"/>

$HeadTitle = "";  // This is the <title>
$HeadDesc = "";   // This is the <desc>

// You need a class that can open a mysql database. There are several options:
//require_once("/home/bartonlp/includes/dbclass.i.php");
// $DB = new Database("localhost:3306", "2844", "7098653", "granbyrotarydotorg");
// Either require_once() a file that has a "Database" class that a "query" and "getDb" method and handles database errors.  or
// point to your private site class. The site class MUST of course have the database function "query" at a minimum!
// For my sites I have a dbclass.i.php which does all this.
//require_once("/home/bartonlp/granbyrotary.org/htdocs/rotary.i.php");
//$DB = new GranbyRotary;

// You need a $PageHead variable that has the text <head>...</head>. You can add that right here as:
// $PageHead = <<<EOF etc.
// or you can include a file and use the ob_start()...$PageHead = ob_get_clean();
// or some other approach like from a class.
// Examples:
// $PageHead = <<<EOF
//   <html><head><title>$HeadTitle</title>
//   <meta name="description" content="$HeadDesc"/>
//   <!-- Script for this page -->
//   <!-- Style for this page -->
//   </head>
// EOF;
// or
// Read the head.i.php file into a variable. This file has the <head>...</head> section with two comments
// <!-- Script for this page --> and <!-- Style for this page --> which can be replaced with script and style markup.
// ob_start();
// include("/home/bartonlp/granbyrotary.org/htdocs/head.i.php"); // CHANGE THIS for your site
// $PageHead = ob_get_clean();

//***************************************************************************************************

// The location of the email template to use.
// The template should look like:
//
// From: 
// To: 
// Subject:
// %boundry1%
// %boundry2%
// %boundry3%
//
// The From, To, and Subject can have tags like <:from:> etc. or they can be blank.
// The %boundryN% where N is 1, 2, or 3, is the boundry markers between the plain text section and the html section. The plain
// text would go between %boundry1% and %boundry2% and the html would go between %boundry2% and %boundry3%. You can place tags at
// these points and have the text in the fields.txt file or in the $fields array below.
// You can make custom templates and change the name below.

$EmailTemplate = ""// for example "/home/bartonlp/granbyrotary.org/htdocs/scripts/emailtemplate.txt";

// The GlobalFooter function should at least have </body></html> tags.
// Each Page can have its own footer text (without the </body></html> tags, or the page footers can just
// return "";

function GlobalFooter() {
  // You could also put a link back to a main page etc.
  return <<<EOF
</body>
</html>
EOF;
}

// The sections that follow can be modified to produce special results

//***************************************************************************************************
// Start Page1: Initial Page that is displayed

// Page1Init has the styles and script for the initial page.
// Change this to add style or scripts into the <head> section.
// If you have no special script or style just return $PageHead;

function Page1Init() {
  global $PageHead;

  /* For example
  $style = <<<EOF
YOU COULD ADD LINKS TO CSS FILES
<style type="text/css">
PUT STYLE STUFF IN HERE
</style>

EOF;

  $script = <<<EOF
YOU COULD ADD JAVASCRIPT LIBRARIES like jQuery etc.
<script type='text/javascript'>
PUT JAVASCRIPT STUFF HERE
</script>  

EOF;
  // DO REPLACEMENT
  $PageHead = preg_replace("/<!-- Script for this page -->/", $script, $PageHead);
  $PageHead = preg_replace("/<!-- Styles for this page -->/", $style, $PageHead);
  */
  return $PageHead;
}

// Bannar for page 1
// If you have a banner like the Granby Rotary (http://www.granbyrotary.org) top of page navigator add it here.
// Otherwise create html here for a banner or return "";
// Each page has a banner function.

function Page1Banner() {
  // Use a class method like this:
  // global $DB;
  // return $DB->header("<h2>Send Emails: Select recipients</h2>");
  // or just return markup like this:
  // return "<h1>This is the top of the page</h1><hr/>";
  // or return "";
  return "";
}

// Page Footer. If a page has no special footer just return "". The GlobalFooter function should always at least do
// </body></html>

function Page1Footer() {
  // add something like: return "<h2>End of page 1</h2>\n";
  return "";
}

// Table1 is for page 1, the initial page which shows the names to select.
// <thead> for Table1
// This table has the names etc to select like "Name", "Email" etc.

$Page1Table1Thead = ""; // for example: "<tr><th>Select</th><th>Member Name</th><th>E-Mail</th><th>Club</th><th>Status</th></tr>";

// Query for Table1.
// This can be a complex as needed even to the extent of having aditional queries to gather information to use in this query.

function Page1Table1Query() {
  // like this: return "select id, concat(FName, ' ', LName) as memberName, Email, club, status from rotarymembers order by
  // status, club";
  // or "select * from xx". The tags below will be the field names so make sure they make sense.
  return "";
}

// <tbody> for Table 1

function Page1Table1Tbody($row) {
  extract($row);

  /* for example:
  return <<<EOF
<tr>
<td><input type="checkbox" name="box[]" value="$id" /></td>
<td>$memberName</td>
<td>$Email</td>
<td>$club</td>
<td>$status</td>
</tr>

EOF;
  */
  retrun "";
}
// End Page1

//***************************************************************************************************
// Start Page2
// Add styles and scripts if needed
// Similar to Page1

function Page2Init() {
  global $PageHead;
  return $PageHead;
}

function Page2Banner() {
  return "";
}

// Text to go before the <textarea> to explain the fields and how to edit the template.
// Put any makeup you want here. If you don't want to explain how the template should be edited just return "".

function Page2Explain() {
  /* Example:
  return <<<EOF
<div style="padding: 10px; border: 1px solid black; margin-bottom: 5px">
<p>The email template file (emailtemplate.txt) has a number of tags that look like &lt;:tagname:&gt;.
These tags are replaced by items from the fields.txt file and the database query  (see sendemails.conf).
Typical tags are:
&lt;:memberName:&gt;, &lt;:plaintext:&gt;, etc.</p>

<p>You can make your own emailtemplate.txt file. Copy the standard emailtemplate.txt file and call it whatever you like.
Then edit the sendemails.conf file and change the \$EmailTemplate variable to point to your new file.</p>

<p>You can edit the fields.txt file and create new fields. Insert these tags into the text below or make a new
emailtemplate.txt file. You can remove tags and add your static text. For example, the &quot;From:&quot; element
at the top can have the tag removed and a static name and email address added.</p>
<p>You can add plain and html text by either adding before or after the tags &lt;:plaintext:&gt; or &lt;:htmltext:&gt;, or
remove these tags and add your text between the %boundry1% and %boundry2% tags for plaintext or between the
%boundry2% and %boundry3% tags for html. The &lt;:plaintext:&gt; and &lt;:htmltext:&gt; are tags from the fields.txt file
which you can change.</p>
<p>You can insert third party images into the html section. Be sure to use the fully qualified URL including the &quot;http://&quot;
of the URL.</p>
</div>

EOF;
*/
  return "";
}

// Get the email template. You can read a file or just return the template as text

function Page2GetEmailTemplate($template="") {
  // example of reading a file:
  // global $EmailTemplate;
  // return file_get_contents($EmailTemplate);

  if(isset($template)) {
    return file_get_contents($template);
  }

  // or just return text like this:

  return <<<EOF
From: 
To: 
Subject:
%boundry1%
%boundry2%
%boundry3%
EOF;
}


// This is the array of static tags.
// You have several options:
// 1) you can fill the array via the Page3GetFields function,
// 2) you can manually fill the array by adding items to the array(...). The format is array("keyname"=>value, ...),
// 3) you can do a bit of both, add values to the array manually and via the function.
// If you only want manual entries then the function should just return.

$fields = array(); // fill this manually and/or use the Page3GetFields function to fill it from a file like fields.txt.

// If you only want the values you manually entered into the $fields array then Page3GetFields should just do a return.

function Page2GetFields() {
  global $fields;

  if(!file_exists("fields.txt")) {
    return "";
  }
  
  $contents = file_get_contents("fields.txt");

  // Remove comment lines that start with # and blank lines
  
  $contents = preg_replace(array("/^\#.*?$/m", "/^\s*/m"), '', $contents);
  
  preg_match_all("/^(.*?)=(.*?)<::>$/sm", $contents, $m);
  
  for($i=0; $i < count($m[1]); ++$i) {
    $fields[$m[1][$i]] = $m[2][$i];
  }

  $msg = "<ul>\n";
  foreach($fields as $key=>$value) {
    $msg .= "<li>&lt;:$key:&gt;=" . escapeltgt($value). "</li>\n";
  }
  $msg .= "</ul>\n";

  return $msg;
}

function Page2Footer() {
  return "";
}
// End Page2

//***************************************************************************************************
// Start Page3

function Page3Init() {
  global $PageHead;
  return $PageHead;
}

function Page3Banner() {
  return "";
}

function Page3Footer() {
  return "";
}

// The query to get the name and email address for the email. $ids is a string of id like "1,19,27" that index into the database
// you are using.

function Page3Query($ids) {
  // for example:
  // return "select concat(FName, ' ', LName) as memberName, Email as memberEmail from rotarymembers where id in ($ids)";
  return "";
}

// Add the values from the database query to the $fields array. Page3Query() field names are used so you may want to make sure
// the fields have good name by using the mysql "as" statement. For example, if the query is:
// "select concat(FName, ' ', LName) as fromname, Email as fromemail from xxx;"
// then the fields array would have the following added: array("fromname"=>a_name_from_table, "fromemail"=>the_email_from_table).
// This is done for each row.

function Page3GetTags($row) {
  global $fields;

  $ar = $fields; // Init the $ar array with the static values from $fields above
  
  foreach($row as $key=>$value) {
    $ar[$key] = $value;
  }
  return $ar; // return new array of static plus database tags
}
// End Page3

//***************************************************************************************************
// Helper function

// Change < and > into "&lt;" and "&gt;" entities

function escapeltgt($value) {
  $value = preg_replace(array("/</", "/>/"), array("&lt;", "&gt;"), $value);  
  return $value;
}

// Now load the sendemails.i.php from where every you want to keep it. This file does not need to be with this file it can be
// anywhere. I doesn't even need to be within the web server's scope you can load it from anywhere on you site.
// For example:
// require_once("/tmp/sendemails.i.php");

require_once("sendemails.i.php"); // This would include it from the directory where this sendemail.conf.php is.

?>