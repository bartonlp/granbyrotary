<?php
/**
 * GranbyRotary Class
 *
 * This class provides methods for www.granbyrotary.org
 * This classs extends the Database base class.
 * @see db.class.php
 * @package GranbyRotary
 * @author Barton Phillips <barton@bartonphillips.com>
 * @version 1.0
 * @link http://www.bartonphillips.com
 * @copyright Copyright (c) 2010, Barton Phillips
 * @license http://opensource.org/licenses/gpl-3.0.html GPL Version 3
 */

// One header file with class

// Almost all of the pages requre_once this file first so it is NOT inluded here. However I may have missed some old pages that
// included rotary.i.php instead of the conf file.
/**
 *
 */

/* 
$DocRootPath = "/home/bartonlp/granbyrotary.org/htdocs"; // root of the web page. 
$IncludePath = "/home/bartonlp/includes"; // This directory
$DatabaseFile = "$IncludePath/db.class.php";

// Database Information

$Host = "localhost:3306";
$User = "2844";
$Password = "7098653";
$Database = "granbyrotarydotorg";
*/

require_once($DatabaseFile); // from above

// BE CAREFUL this could change!!!
define(ID_BARTON, 25);  // define my database id

/**
 * @package GranbyRotary extends Database
 */

class GranbyRotary extends Database {
  // DOCTYPE Constants
  const DOCTYPE_NONE =  0;         // No Doctype header
  const DOCTYPE_4_01_STRICT = 1;   // 4.01 Strict
  const DOCTYPE_4_01_TRANS = 2;    // 4.01 Transitional
  const DOCTYPE_XHTML_STRICT = 3;  // XHTML Strict
  const DOCTYPE_XHTML_TRANS = 4;   // XHTML Transitional

  // Current Doc Type
  private $doctype;
  // Array of Doc Types
  private $doctypes;

  private $hasjsid;
  private $endpolipdb;
  
  // These should be private but I have too many references to them
  // as publics
  
  public $GrId = 0;
  public $GrUser;  // "$FName $LName" as one unit from database, or empty
  public $GrEmail; // $Email from database, or empty
  public $GrDistrictId = 0;
  public $GrIsMember = false;
  public $self;
  public $ip;
  public $agent;
  public $blpIp;
  
  /**
   * Constructor
   *
   * Connects database, does page count optionally.
   * @param boolean $count Default true. If true do the counter logic else don't
   */
  
  public function __construct($count=true) {
    global $Host, $User, $Password, $Database; // From granbyrotary.conf

    $this->self = $_SERVER['PHP_SELF'];
    
    // Call the Database constructor.

    parent::__construct($Host, $User, $Password, $Database);

    // Initialize the doctypes array
    
    $type1 = '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">';
    $type2 = '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">';
    $type3 = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">';
    $type4 = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">';


    $this->doctypes = array('', $type1, $type2, $type3, $type4);

    $this->blpIp = gethostbyname("bartonphillips.dyndns.org"); // get my home ip address
    $this->ip = $ip = $_SERVER['REMOTE_ADDR'];
    $this->agent = $agent = mysql_real_escape_string($_SERVER['HTTP_USER_AGENT']);

    $this->CheckId(); // sets up the Gr** fields

    // If $count is not true don't do any database stuff

    if($count) {
      $filename = $this->self; // get the name of the file

      $this->query("insert into logip (ip, count, id) values('$ip', '1', '$this->id') " .
                   "on duplicate key update count=count+1, id=$this->id");

      // save IP, AGENT, ID info

      $this->query("insert into logagent (ip, agent, count, id) values('$ip', '$agent', '1', '$this->id') " .
                   "on duplicate key update count=count+1, id='$this->id'");

      if($this->id) {
        // Count member's access to pages
        // Only count members

        $this->query("update rotarymembers set visits=visits+1, visittime=now() where id='$this->id'");

        // create or update memberpagecnt

        $this->query("insert into memberpagecnt (page, id, ip, agent, count) " .
                     "values('$filename', '$this->id', '$ip', '$agent', 1) " .
                     "on duplicate key update count=count+1, ip='$ip', agent='$agent'");
      }

      $this->daycount("all");
    }
  }

  /**
   * Check for Has Javascript enabled
   */
  
  private function hasjs() {
    $blpIp = $this->blpIp;
    $ip = $this->ip;

    //echo "IN HASJS: ip=$ip<br>";

    if($ip != $blpIp) {
      //echo "ip!=blpip false<br>";
      
      if(empty($this->endpoliodb)) {
        $this->endpoliodb = new Database('localhost:3774', '3774', 'eegieL7aiqu3', 'endpoliodotcom');
      }
      
      $result = $this->endpoliodb->query("select ip from bots where ip='$ip'");

      if(!mysql_num_rows($result)) {
        $filename = $this->self;
        $agent = $this->agent;

        $this->hasjsid = null;
        
        $query = "insert into hasjs (ip, memberid, agent, filename) values('$ip', '$this->id', '$agent', '$filename')";
        try   {
          $this->query($query);
          $id = mysql_insert_id($this->db);
          $this->hasjsid = $id;
          //echo "in hasjs() id=$id<br>";
          
        } catch(SqlException $e) {
          $err = $e->getCode();
          
          if($err == 1146) {
            // If table does not exist create it
            //echo "Caught Exception error code 1146<br>";
            $query2 = <<<EOF
CREATE TABLE `hasjs` (
  `id` int(11) NOT NULL auto_increment,
  `ip` char(15) NOT NULL,
  `memberid` int(11),
  `agent` varchar(255) not null,
  `filename` varchar(255) not null,
  `count` int(11) default 1,
  `jcount` int(11) default 0,
  `lasttime` timestamp,
  PRIMARY KEY  (`id`),
  UNIQUE KEY (`ip`, `agent`, `filename`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
EOF;
            $this->query($query2);
            $this->query($query);
            $this->hasjsid = mysql_insert_id($this->db);        
          } elseif($err == 1062) {
            // Duplicate key
            $this->query("update hasjs set count=count+1 where ip='$ip'");
            $result = $this->query("select id from hasjs where ip='$ip'");
            list($id) = mysql_fetch_array($result);
            $this->hasjsid = $id;
          } else {
            //echo "db=" . $this->db . ", endpoliodb=" . $this->endpoliodb->db . "<br>";
            //exit();
            // Any other error just rethow the exception
            throw($e);
          }
        }
      }
    }
  }
  
  /**
   * Get Page Top
   * Gets both the page <head> section and the banner
   * The first argument is either a string or an array and is required.
   * The array version has the 'title', 'description', 'script&styles etc', 'documennt type', and 'banner',
   * (it can also look like $header=>array(head=>array(), banner=>"banner"), where head can have 'title','desc', 'extra' and 'doctype'
   * and banner has a banner string. The is depreciated).
   * The string version has just the 'title' which is then used for the 'description' also.
   * The second argument is optional and a string with the 'banner'. The banner can either be part of the first argument as
   * 'banner' or the second argument. If the second argument is not present then $header[banner] is used (which could also be null).
   *
   * @param string|array $header assoc array [title][desc][extra][doctype][banner] or string title
   * @param string $banner
   * @param string $bodytag a custome body tag, defaults to null
   * @return string with the <head> section and the banner.
   */

  public function getPageTop($header, $banner=null, $bodytag=null) {
    if(is_string($header)) {
      $head = array(title=>$header); // Make the $head array
    } elseif(is_object($header)) {
      foreach($header as $k=>$v) {
        $head[$k] = $v; // turn the object into the $head array
      }
    } elseif(is_array($header)) {
      // Check for old version of header which has head=> and banner=>
      if($header[head]) {
        $head = $header[head];
        $banner = $header[banner];
      } else {
        $head = $header;
      }
    } else {
      throw(new Exception("Error: Wrong argument type"));
    }
    
    if(!$head[doctype]) {
      $head[doctype] = self::DOCTYPE_4_01_TRANS;
    }

    $banner = $banner ? $banner : $head[banner];
    
    $head = $this->getPageHead($head[title], $head[desc], $head[extra], $head[doctype], $head[nohasjs]);
    
    $banner = $this->getBanner($banner, $bodytag);
    return "$head\n$banner";
  }

  public function isxhtml() {
    return ($this->doctype == self::DOCTYPE_XHTML_STRICT || $this->doctype == self::DOCTYPE_XHTML_TRANS);
  }

  /**
   * Returns the CURRENT DocType used by this program
   */
  
  public function getDoctype() {
    return $this->doctype;
  }

  /**
   * Return the Document Type String of a) the current document or b) $type
   * @param int $type defaults to null
   * @return string DocType or false if $type is not a doc type. Use === or !== to test for false as DOCTYPE_NONE returns ''.
   */
  
  public function getDoctypeString($type=null) {
    if(!is_null($type)) {
      if(!in_array($type, array_keys($this->doctypes))) {
        return false;
      }
      return $this->doctypes[$type];
    } else {
      return $this->doctypes[$this->doctype];
    }
  }

  /**
   * Get the page <head></head> stuff including the doctype etc. 
   */

  public function getPageHead(/*$title, $desc=null, $extra=null, $doctype=self::DOCTYPE_4_01_TRANS, $nohasjs=false*/) {
    $n = func_num_args();
    $args = func_get_args();
    //vardump($args, "ARGS");
    
    $arg = array(); //new stdClass;

    if($n > 5) {
      throw(new Exception("Error: getPageHead() too many arguments n=$n"));
    }
    
    if($n == 1) {
      $a = $args[0];
      if(is_string($a)) {
        $arg[title] = $a;
      } elseif(is_object($a)) {
        //echo "IS OBJECT<br>\n";
        foreach($a as $k=>$v) {
          echo "$k=$v<br>\n";
          $arg[$key] = $v;
        }
      } elseif(is_array($a)) {
        $arg = $a;
      } else {
        throw(new Exception("Error: getPageHead() argument no valid: ". var_export($a, true)));
      }
    } elseif($n > 1) {
      $keys = array(title, desc, extra, doctype, nohasjs);
      $ar = array();
      for($i=0; $i < $n; ++$i) {
        $ar[$keys[$i]] = $args[$i];
        $arg = $ar;
      }
    }

    $arg[doctype] = !is_null($arg[doctype]) ? $arg[doctype] : self::DOCTYPE_4_01_TRANS;
    
    //vardump($arg, "ARG IN CLASS");
    
    $this->doctype = $arg[doctype];

    if(is_null($arg[desc])) {
      $arg[desc] = $arg[title];
    }

    if($arg[doctype] == self::DOCTYPE_XHTML_STRICT || $arg[doctype] == self::DOCTYPE_XHTML_TRANS) {
      $xml = '<?xml version="1.0" encoding="UTF-8" ?>' . "\n";
      $html = '<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">';
    } else {
      $html = '<html>';
    }

    $dtype = $this->doctypes[$arg[doctype]];

    
    if(!$arg['nohasjs']) {
      $this->hasjs();
    }
    
    $hasjsstuff = '';

    //echo "HASJSID=$this->hasjsid<br>";
    
    if($this->hasjsid) {
      $hasjsstuff = <<<EOF
  // Has Js Logic
  var hasjsid = $this->hasjsid;
  //alert("jsid=" + hasjsid);
  $.get("/hasjs.ajax.php", {id: hasjsid}, function(data) {
    if(data |= "OK") {
      alert("HasJs :" + data);
    }
  });

EOF;
    }

    $pageHead = <<<EOF
$xml$dtype
$html
<head>
  <title>$arg[title]</title>

  <!-- METAs -->
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="copyright" content="2009-2010, Rotary Club of Granby Colorado" />
  <meta name="Author" content="Barton L. Phillips, mailto:barton@granbyrotary.org"/>
  <meta name="description" content="$arg[desc]"/>
  <meta name="keywords" content="Rotary, Granby, Grand County, Colorado, Grand County All-Club Email"/>

  <!-- Microsoft verification tag -->
  <meta name="msvalidate.01" content="769E2BFA62FFED5C91B7F4200CECA90A" />
  <!-- Google verification tag -->
  <meta name="google-site-verification" content="FtWTx_Hn0ie5lTF42jPm5zjVtsDtBFC1MC7kyDJ99AU" />
  <meta name="verify-v1" content="dgAIXuJJft+YWGYjqA2g/NbkCkbfkMdqtAjtx3E4nkc="/>

  <!-- FAVICON.ICO -->
  <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
   
  <!-- RSS FEED -->
  <link href="http://feeds2.feedburner.com/http/wwwgranbyrotaryorg"
       title="Subscribe to my feed"
         rel="alternate"
        type="application/rss+xml" />
   
  <!-- Link our custom CSS -->
  <link rel="stylesheet" title="Rotary Style Sheet" href="/css/rotary.css" type="text/css"/>

  <!-- jQuery -->
  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.0/jquery.min.js"></script>

  <!-- Screen size logic -->
  <script type="text/javascript">
jQuery(document).ready(function($) {
  var xscreen = screen.width;
  var yscreen = screen.height;
  var s = xscreen + "x" + yscreen; // + " " + x + "x" + y;
  $.get("/screensize.ajax.php", { size: s }, function(data) {
    if(data != "OK") {
      $.get("/javaerror.ajax.php", { msg: "Error: screensize.ajax.php: " + data, where: "$this->self", screen: s });
    }
  });
  $hasjsstuff

  // Page Resizing

  var oldfontsize = $("body").css("font-size");

  var p = .95;
  var wid = 580;

  if($("html").outerWidth() < wid) {
    var www = $("html").outerWidth();
    $("body").css("font-size", "8px");
    $("#navMap").css("width", www * p + "px");
    $("#navMap li a").css({float: "none", color: "black","background-color": "transparent"});
    $("#navMap li").css({border: "0px", display: "block"});
  }

  // Change stuff to work on windows smaller than 800px
  
  $(window).resize(function() {
    var w = $("html").outerWidth();
    var ww = screen.width;
    if(ww < wid) {
      $("body").css("font-size", "8px");
    } else {
      if(w < wid) {
        $("body").css("font-size", "8px");
        $("#navMap").css("width", w * p + "px");
        $("#navMap li a").css({float: "none", color: "black","background-color": "transparent"});
        $("#navMap li").css({border: "0px", display: "block"});
      } else {
        $("body").css("font-size", oldfontsize);
        $("#navMap").css("width", "");
        //$("#navMap li a").css("float", "left");
        $("#navMap li, #navMap li a").removeAttr("style");
      }
    }
  });
});
  </script>
$arg[extra]
  <!-- script -->
  <!-- Script for this page -->
  <!-- Styles for this page -->

</head>

EOF;
    if(!($arg[doctype] == self::DOCTYPE_XHTML_STRICT || $arg[doctype] == self::DOCTYPE_XHTML_TRANS)) {
      $pageHead = preg_replace("|/>|", ">", $pageHead);
    }
    
    return $pageHead;
  }

  /**
   * Get the banner 
   * @param string $pageTitle Default blank
   * @param string $mainTitle Default Rotary Wheel image etc.
   * @return string
   */
  
  public function getBanner($pageTitle = "",
                            $mainTitle = "<img src='/images/wheel.gif'
                                             title='Granby Rotary Club'
                                               alt='Rotary Wheel'/>\n<h1>The Rotary Club of Granby</h1>\n", $bodytag=null)
  {
    $bodytag = $bodytag ? $bodytag : "<body>";

    $ret =  <<<EOF
$bodytag
<div id='navMap'>
   <ul>
      <li id ='NMhome'>
         <a href='/index.php'>Home</a>
      </li>

      <li id='NMabout'>
         <a href='/about.php'>About&nbsp;Rotary</a>
      </li>

      <li id='NMcalendar'>
         <a href='/calendar.php'>Club Calendar</a>
      </li>
EOF;

   if(!$this->id) {
      $ret .= <<<EOF
      <li id='NMLogin'>
         <a href='/login.php'>Login</a>
      </li>
EOF;
   } else {
      $ret .= <<<EOF
      <li id='NMProfile'>
         <a href='/edituserinfo.php'>User Profile</a>
      </li>
EOF;
   }
      
   $ret .= <<<EOF
      <li id='NMmembers'>
         <a href='/member_directory.php'>Members</a>
      </li>

      <li id='NMhits'>
         <a href='/hits.php'>Web Stats</a>
      </li>

      <li id='NMnews'>
         <a href='/news.php'>News</a>
      </li>

      <li id='NMmeetings'>
         <a
          href='/meetings.php'>Meetings</a>
      </li>
   </ul>
   <br/>
</div>
<div id='pagetitle'>
$mainTitle
$pageTitle
</div>

<noscript>
<p style='color: red; background-color: #FFE4E1; padding: 10px'>Your browser either does not support <b>JavaScripts</b> or you have JavaScripts disabled, in either case your browsing
experience will be significantly impaired. If your browser supports JavaScripts but you have it disabled consider enabaling
JavaScripts conditionally if your browser supports that. Sorry for the inconvienence.
</noscript>

EOF;

  // WARNING About MSIE!

  preg_match('/(MSIE.*?);/', $_SERVER[HTTP_USER_AGENT], $m);
  $msie = $m[1];

  $ret .= <<<EOF
<!--[if lt IE 7]>
<hr>
<p style='color: red; background-color: white; border: 1px solid black; padding: 5px;'>
You are running a version of Internet Explorer ($msie).
Unfortunatly IE is not very standards compliant.
There are several fratures that may not work correctly on this page depending on the
version of Internet Explorer you are using.
This page has been tested with
<a href='http://www.getfirefox.com'>Firefox</a>,
<a href='http://www.google.com/chrome'>Chrome</a>,
<a href='http://www.opera.com'>Opera</a>,
<a href='http://galeon.sourceforge.net/download/'>Galeon</a>, and
<a href='http://www.apple.com/safari/download/'>Safari</a>
and works well.
For best results download either Firefox or Chrome. I highly recomend changing your
browser to one of the standard complient browsers.</p>
<![endif]-->
<!--[if IE 8]>
<p style='color: red; background-color: white; border: 1px solid black; padding: 5px;'>
You are running Internet Explorer 8. This site has been tested with IE 8 and appears to work correctly at this time;
however, as new features are added it may not be possible to continue to make everything work with IE. Sorry.</p>
<![endif]-->
<!--[if IE 7]>
<p style='color: red; background-color: white; border: 1px solid black; padding: 5px;'>
You are running Internet Explorer 7. This site has been tested with IE 7 and appears to work correctly at this time;
however, as new features are added it may not be possible to continue to make everything work with IE. Sorry.</p>
<![endif]-->
<!--[if gte IE 7]>
<p style='color: red; background-color: white; border: 1px solid black; padding: 5px;'>
Even though IE 7 and 8 are somewhat standard complient it would be better to run Firefox, Opera or Safari.</p>
<![endif]-->
<!--[if lte IE 6]>
<span style='color: white; background-color: red; border: 1px solid black; padding: 5px;'>
Really any Internet Explorer less then version 7 just does not work!
If you must use IE please upgrade to 7 or above.</span>
<![endif]-->

<hr/>

EOF;
   return $ret;
  }

  /**
   * Get footer
   * @param string $msg Default blank
   * @param string $wc2val Default blank
   * @param string $ctrMsg Default blank
   * @param bool $google
   * @return string
   */
  
  public function getFooter($msg='', $wc3val='', $ctrMsg='', $google=true) {
    ob_start();
    if($msg) {
      print("<div id='footerMsg'>$msg</div>\n");
    }

    if($ctrMsg) {
      $this->counter($ctrMsg);
    } else {
      $this->counter(); // Display counter
    }
    
    // The club is in Colorado but the server is San Diego
    
    date_default_timezone_set('America/Denver');
    $rdate = getlastmod();
    $date = date("M d, Y H:i:s", $rdate);

    $x = new DateTime($date);
    $off = $x->getOffset();

    $daylite = $off == -21600 ? "MDT" : "MST"; // 21600 min = 6 hr

    echo <<<EOF
<p id='lastmodified'>Last Modified&nbsp;$date $daylite</p>
<p id='contactUs'><a href='mailto:info@granbyrotary.org'>Contact Us</a></p>

EOF;

    // validation if pressent
    if(!empty($wc3val)) {
      print($wc3val);
    }
    
    // Google Analysis code

    if($google) {
      echo <<<EOF
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-713599-2");
pageTracker._trackPageview();
} catch(err) {}
</script>

EOF;
    }
    // ADD ENDING 
    echo "</body>\n</html>\n";
    
    $m = ob_get_clean();
    return $m;
  }

  // In our case $inc is 'all' so we count for any page hit
  
  private function daycount($inc) {
    $ip = $this->ip;
    $blpIp = $this->blpIp;

    // Dont count us. GrId test is specific to Rotary!!

    if($ip != $blpIp && $this->id != ID_BARTON) {
      if($inc) {
        if(is_array($inc)) {
          $what = key($inc);
          $check = $inc[$what];
        } elseif($inc == "all") {
          $what = $check = "all";
        } else {
          $what = $this->self;
          $check = $inc;
        }
      } else {
        $what = $this->self;
        $check = "/index.php";
      }

      // What page to count.
      
      if($what == $check) {
        // Check if this ip is a ROBOT

        $result = $this->query("select curdate()");
        $curdate = mysql_result($result, 0);

        if(empty($this->endpoliodb)) {
          $this->endpoliodb = new Database('localhost:3306', '3774', 'eegieL7aiqu3', 'endpoliodotcom');
        }
      
        $result = $this->endpoliodb->query("select ip from bots where ip='$ip'");

        if(mysql_num_rows($result)) {
          // BOT
          $this->query("insert into daycounts (date, count, robotcnt, visits, ip) " .
                       "values('$curdate', 1, 1, 0, '$ip') " .
                       "on duplicate key update count=count+1, robotcnt=robotcnt+1");
        } else {
          // NOT BOT
          $this->query("insert into daycounts (date, count, visits, ip) " .
                       "values('$curdate', 1, 0, '$ip') " .
                       "on duplicate key update count=count+1");
        }

        if($this->id) {
          echo "Member id=$this->id<br>";
          $this->query("update daycounts set members=members+1 where ip='$ip' and date='$curdate'");
        }
        
        if(!($cookietime = $_COOKIE[blptime])) {
          $cookietime = time();
          // set cookie to expire in 10 minutes
          setcookie("blptime", $cookietime, $cookietime + (60*10), "/", "granbyrotary.org", false, true);
          $this->query("update daycounts set visits=visits+1 where ip='$ip' and date='$curdate'");
        }
      }
    }
  }
  
  /**
   * Set the ID cookie
   */
  
  public function SetIdCookie($id) {
    $this->id = $id;
    $expire = time() + 31536000;  // one year from now

    $ref = ".granbyrotary.org";

    setcookie("GrId", $id, $expire, "/", $ref);
  }

  /**
   * Get the ID
   */
  
  public function GetId() {
    return $this->id;
  }

  /**
   * Get the user name
   */
  
  public function GetUser() {
    return $this->GrUser;
  }

  /**
   * Get the user's email address
   */
  
  public function GetEmail() {
    return $this->GrEmail;
  }

  /**
   * Set the ID
   */
  
  public function SetId($id) {
    $this->id = $id;
  }

  /**
   * Set the user's name
   */
  
  public function SetUser($user) {
    $this->GrUser = $user;
  }

  /**
   * Set the user's email address
   */
  
  public function SetEmail($email) {
    $this->GrEmail = $email;
  }

  /**
   * Check ID info
   *
   * As a side effect sets the $this->GrUser, GrEmail, GrDistrictId, and GrId by reading rotarymembers table.
   * @return user's id (GrId)
   */
  
  public function CheckId() {
    $id = $_COOKIE['GrId'];
    
    if(!isset($id)) {
      return 0;
    }

    $result = $this->query("select FName, LName, Email, districtId, otherclub from rotarymembers where id='$id'");

    if(mysql_num_rows($result) == 0) {
      // OPS DIDN'T FIND THE ID IN THE DATABASE?
      return 0;
    }

    $row = mysql_fetch_assoc($result);
    extract($row);
    $this->GrUser = "$FName $LName";

    $this->GrEmail = $Email;

    $this->GrDistrictId = $districtId;

    $this->GrIsMember = $otherclub == 'none' ? false : true;
    
    // check the database to see if fastconnect is not null. 
    // if not null is it "y"? set to true of false.

    $this->id = $id;
    return $id;
  }

  /**
   * Checks and Setss the ID cookie
   * @return user's ID (GrId)
   */
  
  public function CheckAndSetId() {
    $id = $this->CheckId(); 

    if($id)
      setidcookie($id);

    return $id;
  }

  /**
   * Check user
   * @return blank or number of new bulletin board entries ("<br/>$cnt New Post" . ($cnt == 1 ? "" : "s")
   */
  
  public function CheckBBoard() {
    $msg = "";

    $id = $this->GetId();

    if($id) {
      $result = $this->query("select count(item) from bboard");  // count all items in bboard

      $row = mysql_fetch_row($result);

      $bbcount = $row[0]; // total items in bb

      $result = $this->query("select count(item) from bbsreadmsg where id='$id'"); // now count the number of items that I have read

      $row = mysql_fetch_row($result);

      $bbsreadcnt = $row[0]; // items that I have read

      // If there are some items in the bb

      if($bbcount) {
        // subtract the total from what I have read, this is the number
        // of UN read items.

        $cnt = $bbcount - $bbsreadcnt;

        // If ther are any unread items

        if($cnt) {
          $msg = "<br/>$cnt New Post" . ($cnt == 1 ? "" : "s");
        }
      }
    }
    return $msg;
  } 

  /**
   * Count number of accesses to the rss feed.
   *
   * Inserts into database table "feedcnt"
   */
  
  public function feedCount() {
    $agent = $this->agent;
    $result = $this->query("insert into feedcnt (agent, count) values('$agent', 1) on duplicate key update count=count+1");
  }
  
  /**
   * Displays Page Hits
   * @access private
   */
   
  private function counter($msg='Number of Hits') {
    $filename = $this->self;

    $result = $this->query("select count from counter where filename='$filename'");

    if(mysql_num_rows($result) == 0) {
      // Not in database yet so create an entry for this file

      $this->query("insert into counter (filename, count) values('$filename', '1')");
      $count = 1;
    } else {
      $row = mysql_fetch_row($result);
      $count = $row[0]; // count

      // If this is user Barton Phillips don't count anything!

      if($this->id != ID_BARTON) {
        ++$count;
    
        $this->query("update counter set count='$count' where filename='$filename'");
      }
    }

    // The ctrnumber.php returns an image. The possible arguments are:
    // s=font size. if not pressent defaults to 11
    // text=the message which is usually a number like 11 etc. If not
    // pressent then blank.
    // font=font file, like TIMES.TTF. If not pressent defaults to
    // TIMESBD.TTF
    // rgb=the background color in rgb form like 233,255,100 etc. If not
    // pressent defaults to rgb=245,222,179 which is hex=#F5DEB3

    // the id's hitCounter, hitCounterp, hitCountertbl, hitCountertr,
    // hitCounterth, and ctrnumbers are defined in rotary.css

    echo <<<EOF
<div id='hitCounter'>
   $msg
      <table id='hitCountertbl' style="width: 0">
         <tr id='hitCountertr'>
            <th id='hitCounterth'><img id='ctrnumbers' src='/ctrnumbers.php?s=16&amp;text=$count' alt='$count'/></th>
         </tr>
      </table>
</div>

EOF;
  }

  /**
   * getLastmod
   * @access private
   */
  
  private function getLastmod() {
    // The club is in Colorado but the server is San Diego

    $row = mysql_fetch_assoc($this->query("select max(lasttime) as date from articles"));
    
    return $row['date'];    
  }

  /**
   * Check if the News Page has changed since user looked last
   * @return true or false
   */
  
  public function newsChanged() {
    $d = $this->getLastmod();
    $result = $this->query("select lastnews from rotarymembers where id=$this->id");

    $row = mysql_fetch_assoc($result);
    $lastnews = $row['lastnews'];

    //echo "d=$d, lastnews=$lastnews<br>";
    //echo "d=" . strtotime($d) . " lastnews=" . strtotime($lastnews) . "<br>";

    if(strtotime($d) > strtotime($lastnews)) {
      return true;
    }
    return false;
  }

  /**
   * Set "lastnews" field in "rottarymembers" every time News Page viewed
   */
  
  public function lookedAtNews() {
    // update members lastnews
    date_default_timezone_set('America/Denver');
    $date = date("Y-m-d H:i:s");
    $this->query("update rotarymembers set lastnews='$date' where id='$this->id'");
  }

  /**
   * Get Whos Been Here Today message
   */
  
  public function getWhosBeenHereToday() {
    ob_start();
    echo <<<EOF
<table id="todayGuests" style="width: 100%;">
<tbody>
<tr>
<th style="width: 60%">Who's visited our Home Page today?</th>
<th>Last Time</th>
</tr>

EOF;

  // NOTE the database last field has the San Diego time not our
  // time. So use ADDTIME to add one hour to the time to get Mountain
  // time.

  $result = $this->query("select concat(FName, ' ', LName) as name,
date_format(addtime(visittime, '1:0'), '%H:%i:%s') as last
from rotarymembers where id != 0 and visits != 0 and visittime > current_date() order by visittime desc");

  while($row = mysql_fetch_assoc($result)) {
    echo "<tr><td>" . stripslashes($row['name']) . "</td><td>$row[last]</td></tr>\n";
  }

  echo <<<EOF
</tbody>
</table>

EOF;
    $ret = ob_get_clean();
    return $ret;
  }
  
  /**
   * Login Info Functioin
   * This is only used by the login.php
   * when members first login.
   */
  
  public function loginInfo() {
    // Get the information we want to use

    $agent = $this->agent;
    $ip = $this->ip;

    // save IP, ID info

    $this->query("insert into logip (ip, count, id) values('$ip', '1', '$this->id')
    on duplicate key update count=count+1, id=$this->id");

    // save IP, AGENT, ID info

    $this->query("insert into logagent (ip, agent, count, id) values('$ip', '$agent', '1', '$this->id')
    on duplicate key update count=count+1, id='$this->id'");

    // Now update the users visit counter

    $this->query("update rotarymembers set visits=visits+1, visittime=now() where id='$this->id'");
  }  
}

// End of class GranbyRotary

// Currently the two exception classes are NOT used (3/30/2009

/**
 * @package GranbyRotary Exception
 */

class GanbyRotaryException extends Exception {
  // message, code. file, and line are members of Exception
  
  public function __construct($message, $code=-1) {
    parent::__construct($message, $code);
  }

  public function __toString() {
    // See if we have set_error_handler() set which catches PHP
    // errors and looks to see if the text says mysql. Then it adds
    // CAUGHT and throws a DbExeption.

    return __CLASS__ . "{ [FILE=$this->file] [LINE=$this->line] [Error='$this->message'] }";
  }
}

/**
 * Strip Slashes Deep. Only if function does not already exist
 * @param string|array $value
 * @return string|array $value with slashes removed
 */

if(!function_exists(stripSlashesDeep)) {
  function stripSlashesDeep($value) {
    $value = is_array($value) ? array_map('stripSlashesDeep', $value) : stripslashes($value); 
    return $value;
  }
}

/**
 * Change <> to &lt; &gt;. Only if function does ot already exist
 * @param string $value
 * @return string $value with <> escapped to &lt; and &gt;
 */
 
if(!function_exists(escapeltgt)) {
  function escapeltgt($value) {
    $value = preg_replace(array("/</", "/>/"), array("&lt;", "&gt;"), $value);  
    return $value;
  }
}

// Callback to get the user id for db.class.php SqlError

if(!function_exists(ErrorGetId)) {
  function ErrorGetId() {
    $id = $_COOKIE[GrId];
    if(empty($id)) {
      $id = "IP=$_SERVER[REMOTE_ADDR], AGENT=$_SERVER[HTTP_USER_AGENT]";
    }
    return $id;
  }
}
// Javascript exception types
//
// EvalError - raised when the eval() functions is used in an incorrect manner;
// 
// RangeError - raised when a numeric variable exceeds its allowed range;
// 
// ReferenceError - raised when an invalid reference is used;
// 
// SyntaxError - raised when a syntax error occurs while parsing JavaScript code;
// 
// TypeError - raised when the type of a variable is not as expected;
// 
// URIError - raised when the encodeURI() or decodeURI() functions are used in an incorrect manner;

// WARNING THERE MUST BE NOTHING AFTER THE CLOSING PHP TAG.
// Really nothing not even a space!!!!
?>