<?php
// !!!!! This file should not need to be modified !!!!
// !!!!! Modify the sendemails.php file for your site needs !!!!

// Send emails with a plain text and HTML section.
// Given an email template file header, plain and html email content,
// first: show a list of recipients from one of our databases,
// then: display the email template and allow modifications,
// Finally: send the email.
//

// Page1 show a list of members with check boxes to select
// Page2 get email template and allow modification
// Page3 send email to selected members

$page = $_POST['page'];

switch($page) {
  case 2:
    doPage2();
    break;
  case 3:
    doPage3();
    break;
  default:
    doPage1();
    break;
}

echo GlobalFooter();

// End

// Page Functions

// Initial page with list of names and check boxes for selections

function doPage1() {
  $self = $GLOBALS['self'];
  $DB = $GLOBALS['DB'];
  $emailtemplate = $GLOBALS['EmailTemplate'];
                   
  $pageHead = Page1Init();

  $banner = Page1Banner();
  
  echo <<<EOF
$pageHead
<body>
$banner
<form action="$self" method="post">
Email Template File:<br>
<input type="text" name="emailtemplate" value="$emailtemplate" style="width: 80%"/><br>
<input type="hidden" name="page" value="2" />
<input type="submit" value="Submit Names" />

<table id="table1" border="1">
<thead>
$GLOBALS[Page1Table1Thead]
</thead>
<tbody>

EOF;

  $result = $DB->query(Page1Table1Query());

  while($row = mysql_fetch_assoc($result)) {
    echo Page1Table1Tbody($row);
  }
  echo <<<EOF
</tbody>
</table>
</form>

EOF;
  echo Page1Footer();
} 

// Second page. Edit the template

function doPage2() {
  global $self;

  $pageHead = Page2Init();
  $banner = Page2Banner();

  // $_POST[box] is an array of id's for the database

  if($box = $_POST['box']) {
    $box = implode(",", $box);
  } else {
    echo <<<EOF
$pageHead
<body>
<h1>No Members Selected</h1>
<a href="$self" >Return and select members</a><br>

EOF;
    return;
  }

  $emailtemp = Page2GetEmailTemplate($_POST['emailtemplate']);

  //echo "<br>$emailtemp<br>";

  $explain = Page2Explain();

  list($fields, $passFields) = Page2GetFields();  // init fields for use by Page3GetTag

  //echo "<pre>fields=$fields, passFields=$passFields</pre>\n";

  $tags = Page2ShowTags();

  echo <<<EOF
$pageHead
<body>
$banner
$explain
<form action="$self" method="post">
<textarea id='emailtemplate' name="emailmsg" style="width: 100%" rows="30">$emailtemp</textarea>
<p>Static Tags:</p>
<div style="border: 1px solid black">
$fields
</div>
<p>Tags from database query:</p>
<div style="border: 1px solid black">
$tags
</div>
<div>
<p>Add new static Tags. Format is <b>key=value&lt::&gt;</b>. The &lt::&gt; is the value terminator. values can span lines.
For example:<br>
<code>
mynewtag=This is a test<br>
of this thing<br>
this is a multi line value&lt::&gt;
</code></p>

<textarea id="addfields" name="addfields" style="width: 100%" rows="10"></textarea>
</div>
<input type="hidden" name="Fields" value='$passFields' />
<input type="hidden" name="page" value="3" />
<input type="hidden" name="box" value="$box" /><br>
<input type="submit" value="Submit Email" />
</form>

EOF;

  echo Page2Footer();
}

// Final Page. Send the emails

function doPage3() {
  $DB = $GLOBALS['DB'];

  $pageHead = Page3Init();

  $banner = Page3Banner();

  echo <<<EOF
$pageHead
<body>
$banner

EOF;

  $addfields = "$_POST[Fields]\n$_POST[addfields]"; // This order should let us change fields from fields.txt with addfields

  //echo "<pre>$addfields</pre>\n";

  Page3AddFields($addfields);

  //echo "<p>setGetFields:<br>";
  //var_dump(setGetFields());
  //echo "</p>\n";

  // get required Mail stuff

  require_once('Mail.php');
  require_once('Mail/mime.php');

  // set up for Mail/mime.php
    
  $mime = new Mail_mime("\n");  // use line feeds

  $mail =& Mail::factory('sendmail', Page3GetFactoryParams());

  if($GLOBALS[DEBUG]) {
    echo "Initial Values<br>mail=<br>";
    var_dump($mail);
    echo "<br>mime=<br>";
    var_dump($mime);
    echo "<br>\n";
  }
  
  $ids = $_POST[box];

  $emailmsg = stripslashes($_POST[emailmsg]);

  //$emailmsg = preg_replace('/\\\"/s', '"', $_POST[emailmsg]); // remove escaping backslashes
  
  $query = Page3Query($ids);

  $result = $DB->query($query);

  while($row = mysql_fetch_assoc($result)) {
    $msg = $emailmsg; // make a copy for each iteration and work on the copy

    // list of tag-names. A tag looks like <:tag-name:>. We now want to remove the tag delimiters and replace the tag-name with
    // the tag value from the tables and insert into massemail above

    $ar = Page3GetTags($row);  // fields from the query to make tags of.

    //echo "<pre>ar=\n";
    //var_dump($ar);
    //echo "</pre>\n";

    // replace the tags with the actual values

    foreach($ar as $key=>$value) {
      $rep = "/<:$key:>/sm";
      $msg = preg_replace($rep, $value, $msg);
    }

    // Extract the elements from the message: From: To: Subject: and put them in variables for use later
    
    if(preg_match("/^From:\s+(.*?)\n/sm", $msg, $m)) {
      //echo "from: $m[1]<br>\n";
      $from = $m[1];
    }
    if(preg_match("/^To:\s+(.*?)\n/sm", $msg, $m)) {
      //echo "to: $m[1]<br>\n";
      $to = $m[1];
    }
    if(preg_match("/^Subject:\s+(.*?)\n/sm", $msg, $m)) {
      //echo "subject: $m[1]<br>\n";
      $subject = $m[1];
    }

    // Get the text body form the message
    //echo "<pre>MESSAGE:\n$msg\nEND</pre>\n";

    if(preg_match("/%boundry1%(.*?)%boundry2%/s",
                  $msg, $m)) {
      //echo "text:\n$m[1]<br>\n";
      $bodyText = $m[1];
    }

    // Get the html body form the message
    
    if(preg_match("/%boundry2%(.*?)%boundry3%/s",
                  $msg, $m)) {
      //echo "html:\n$m[1]<br>\n";
      $bodyHtml = $m[1];
    }
    
    $hdrs = array(
                'From'    => $from,
                'Reply-To' => "bartonphillips@gmail.com",   
                'Subject' => $subject
               );


    // We make images with <%img src="path on server"> or with single quotes.

    preg_match_all("/<%img src=['\"](.*?)['\"]/", $bodyHtml, $m);
    
    $bodyHtml = preg_replace("/<%img/", "<img", $bodyHtml);

    //echo "<pre>" . escapeltgt($bodyHtml) . "</pre>\n";

    // Set up the two sections text and html
    
    $mime->setTXTBody($bodyText);
    $mime->setHTMLBody($bodyHtml);

    for($i=0; $i < count($m[1]); ++$i) {
      //echo "<br>img $i: " . $m[1][$i] . "<br>\n";
      $img = $m[1][$i];
        
      $ret = $mime->addHTMLImage($img, 'application/octet-stream');
      if($ret !== true) {
        echo "<br>addHTMLImage error: $img<br/>\n";
      }
    }
    
    //do not ever try to call these lines in reverse order

    $body = $mime->get();
    $hdrs = $mime->headers($hdrs);

    // If debug output info but DO NOT SEND MAIL
    
    if($GLOBALS[DEBUG]) {
      echo "<br><br>Inside Loop Values<br>mail=<br>";
      var_dump($mail);
      echo "<br>mime=<br>";
      var_dump($mime);
      echo "<br>\n";

      echo "<br>*****<br>hdrs:<br>";
      var_dump($hdrs);
      echo "<br>body:<br>";
      var_dump($body);
      echo "<br>********<br>from=". escapeltgt($from) .", to=" . escapeltgt($to) .
          ", subject=$subject<br>plaintext=$bodyText<br>htmltext=<pre>" .
          escapeltgt($bodyHtml) . "</pre>****END<br>\n";
    } else {
      // Do the actual sending of the email!
      $mail->send($to, $hdrs, $body);
    }
    
    // Echo what we did

    $sentto = escapeltgt($to);
    echo <<<EOF
<p>Email sent to <b>$sentto</b></p>

EOF;
  } // end of while
  
  echo Page3Footer();
}

?>

