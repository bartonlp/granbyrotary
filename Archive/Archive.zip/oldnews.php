<?php
require_once("/home/bartonlp/includes/granbyrotary.conf");
$gr = new GranbyRotary;

$page = "";
$hdr = "";

$results = $gr->query("select * from articles where expired < now() order by created desc");

while($row = mysql_fetch_assoc($results)) {
  extract($row);
  switch($articleInclude ) {
    case "article":
      $story = $article;
      break;
    case "rss":
      $story = $rssfeed;
      break;
    case "both":
      $story = "$rssfeed\n$article";
      break;
  }
  $page .= <<<EOF
<div>
$story 
</div>
<p style="color: brown; font-size: 10px; font-style: italic">Creation date: $created</p>

<hr>

EOF;

  $hdr .= "$header";
}
$f = fopen("/tmp/oldnews.i.php", "w");
fwrite($f, $page);
fclose($f);
//chmod("articles/oldnews.i.php", 0666);

?>
<head>
  <title>Old News</title>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
   <meta name="Author" content="Barton L. Phillips, mailto:barton@granbyrotary.org">
   <meta name="description"
      content="Name: Rotary Club of Granby Colorado, Page: Old News">
   <meta name="keywords" content="rotary">

   <!-- Link our custom CSS -->
   <link rel="stylesheet" title="Rotary Style Sheet"
        href="/css/rotary.css" type="text/css">

   <!-- jQuery just incase -->
   <script type="text/javascript" src="/js/jquery-1.3.2.min.js"></script>

   <style type="text/css">
blockquote {
        background-color: #FEF0C9;
        padding: 2px 20px;
}
   </style>

<?php
echo "$hdr";
?>
   
</head>
<body>
<?php
$gr->header("<h2>Old News</h2>");
?>

<!-- DISCLAIMER!!! -->
<div id='disclaimer'
  style='background-color: yellow; width: 30%; border: 1px solid black;
     padding: 10px; margin: 0 auto;'>
   <p>Please note that links on this page may be out of date and may
      not work. While I try to keep the links active, as this is
      old, I may have let some slip. If you encounter broken links I'm
      sorry.</p>
</div>

<hr>

<?php

include("/tmp/oldnews.i.php");

?>

<!-- START OLD NEWS -->

<a name='GSE'></a>
<h2>GSE Dinner Grand Lake Rotary</h2>
<div>
<img src="http://www.granbyrotary.org/images/gse_home_logo.jpg" alt="GSE logo" />
<p>Grand Lake Rotary is hosting the GSE (Group Study Exhnage) dinner
   at 18:00 at the Bear's Den. Everyone is invited.</p>
</div>

<hr>

<a name="Headwaters"></a>
<h2>Headwaters Trail Alliance</h2>

<div style='width: 100%;'>
     
<a href='http://www.headwaterstrails.com'
  style='float: left; width: 43%'>

<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" 
codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0"> 
<param name='movie' value="http://www.headwaterstrails.com/pageheaders.swf"> 
<param name='menu' value='false'> 
<param name='quality' value='high'> 
<param name='wmode' value='opaque'> 
<param name='scale' value='scale'>
<embed src='http://www.headwaterstrails.com/pageheaders.swf'
      menu='false' quality='high' wmode='opaque'
      scale='scale' width='600' type="application/x-shockwave-flash" 
      pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash">
</embed>
</object>

</a>

<p style='float: right; width: 48%; margin-right: 20px'>
   Our April 1<sup>st</sup> noon speaker was Lucinda Elicker from the <b>Headwaters Trails
   Alliance</b>. Lucinda gave a very interesting presentation of the
   current state of the project and the upcoming events scheduled for
   this summer. Much more information about the
   <a href='http://www.headwaterstrails.com'>
   Headwaters Trails Alliance</a> is available at their web site.
</p>

</div>

<br  style='clear: both' /> 

<hr>

<h2>Photos From Winter Park/Fraser Awards Dinner</h2>

<p>These pictures are courtesy of the Fraser River Valley Lions club.
   This is a very nice <a
   href='http://albums.phanfare.com/2110395/3687144#imageID=65076166'>Sideshow</a>
   of the proceedings</p>

<hr>

<h2>Polio Resurgent In Nigeria</h2>

<p>There is still more to do. Here is an article from <a
href='http://www.sciam.com/blog/60-second-science/post.cfm?id=polio-resurgent-in-nigeria-2009-04-03'>
Scientific American</a>. According to the article Polio figures have
gone up recently:</p>

<blockquote>

<p><q> An estimated 350,000 cases of the disease occurred annually in
1988, when world leaders launched the Global Polio Eradication
Initiative to eliminate the virus in the 125-plus countries where it
still existed. By 2006, polio remained endemic to just four countries
-- Nigeria, Afghanistan, India and Pakistan -- and by 2007, the number
of reported cases was down to 1,315. But over the next year,
infections rose by 26 percent, to 1,655 cases, according to the
Morbidity and Mortality Weekly Report.</q>
</p>

<p><q>The biggest jump was in Nigeria, where there were 801 cases last
year, up from 285 in 2007, according to the MMWR. As we noted in
January, the northern part of the country is plagued by flawed
vaccination campaigns that miss up to half of the children that
require them (the oral vaccine is given at birth and in three
subsequent doses over a child's first year.) The report says these
lapses contributed to the disease's spread to six countries -- Benin,
Burkina Faso, Cote d'Ivoire, Ghana, Mali and Togo -- where polio had
been eradicated as well as to Niger and Chad, which had been battling
resurgences of the virus.</q></p>

</blockquote>

<p>The article went on to say <q>In January, the Bill &amp;
Melinda Gates Foundation, Rotary International and the British and
German governments committed to $630 million to eradicate polio.</q>
</p>

<p>More can be found on our <a
href='/clubservice.php#rotaryint'>Service Page</a></p>

<hr>

<h2>Joyce Ackerson</h2>
<p>Rhonda has sent out this email:</p>
<pre style='width: 50%; background-color: #FEF0C9; margin-left: 10px; padding: 20px'>
   
Dear Rotary Members;

Joyce Ackerson has been doing poorly lately.  Her health has been bad,
and she has moved to be with her son.  It would be wonderful if she
got a few cards from the Rotary wishing her well.  Her address is:

Joyce Ackerson
% Rick Ackerson
13716 Hickory Court Drive Haslet, TX
76052

Thanks, Rhonda
</pre>

<hr>

<h2>Wednesday April 8 Noon Meeting</h2>

<p>This was a business meeting. We invited the presidents from the
   other Grand County clubs and
   <ul>
      <li>Rich Rosene from Kremmling</li>
      <li>Glenn Harrington from Grand Lake</li>
      <li>Mark Lund from Winter Park/Fraser</li>
      <li>Steve Radcliffe from Winter Park/Faser</li>
   </ul>
   attended the meeting. After the main meeting the presidents and our
   assistant district governor had a get together to discuss plans for
   the upcoming year.</p>

<p>The main meeting included:
   <ul>
      <li>Treasuers Report: $4,840 in checking, $8,530 foundation
      checking, and $10,658 in foundation CD's</li>
      <li>Secretary Report: 56.2% attendance and 28 active
         members</li>
      <li>Club Activities</li>
      <ul>
         <li>Dictionary Program: Thanks Frank. There are some letters
         from the children <a href='#dictionaryLetter'>below</a></li>
         <li>Dollywood Library now has 76 children enrolled</li>
         <li>Next Blood Drive: May 18</li>
         <li>9Health Fair April 18 see more information <a
         href='oldnews.php#9HealthFair'>below</a></li>
         <li>GSE New Zealand Dinner April 25 at the Bear's Den in Grand
            Lake. Drinks at 6PM Dinner at 7PM cost about $8</li>
         <li>Scholarship: Due 5/1, Present 5/29, Patric to lead</li>
         <li><a href="#earthday">Earth Day</a></li>
         <li>June 19 Fireman</li>
         <li>Forth of July Picnic</li>
         <li>Fish Derby Breakfast 8/15</li>
         <li>Cancer Run Breakfast 8/9</li>
         <li>Vet Pancake Breakfast 8/15</li>
      </ul>
      <li>End Polio Now: we will pay off the year amount of
         $2,100</li>
      <li>Litle League donation paid</li>
      <li>Bench Work Day: no hard date but probably late May</li>
      <li>RI and District:
      <ul>
         <li>Change in Paul Harris points</li>
         <li>District Convention 5/1-5/3</li>
         <li>Club Leader Training in Denver 6/6</li>
         <li>RI giving: our club is third out of 66 -- Pretty
            Good</li>
      </ul>
      <li>Rotary Plaque delivered to Silver Creek</li>
   </ul>
</p>

<hr>

<a name='9HealthFair'></a>

<h2>9HealthFair</h2>

<a href='http://www.9healthfair.org/default.aspx'><img
src='/images/9healthfair.jpg' alt='9HealthFair logo' /></a>

<h3>Where</h3>
<ul>
   <li>Granby Elementary School</li>
   <li>202 W. Topaz Ave.</li>
   <li>Granby , CO   80446</li>
</ul>
<h3>When</h3>
<ul>
   <li>April 18, 2009</li>
   <li>7:00AM - 11:00AM</li>
</ul>

<h3>What</h3>
<ul>
   <li>Basic Screenings</li>
   <li>Blood Count Screening (Blood Draw)</li>
   <li>Body Fat Skinfold Screening</li>
   <li>Breast Screening</li>
   <li>Finger Stick Glucose Screening</li>
   <li>Foot Screening</li>
   <li>Oral Health Screening</li>
   <li>Skin Screening</li>
</ul>   


<p>Anyone wishing to 
   <a
    href='http://www.9healthfair.org/volunteer/volunteersignup.aspx'>Volunteer</a>
   can do it online at the 9HealthFair web site. Some suggested volunteer positions are described <a
   href='9health.php'>here</a></p>

<div id='iVolunteered9HealthFair'>
   <p>You can also volunteer by sending an email to our project
      leader: </p>

   <form id='healthfairform'
    onsubmit="alert('No onger taking voluteers'); return false;">
      <div style='border: 1px solid black; width: 45%; padding: 10px; background-color: red'>
         I want to volunteer. Add my <input type='checkbox'
         name='spouse'/>Spouse as well

         <input type='hidden' name='event' value='9HealthFair' />
         <input type='submit' value='Volunteer Now' />
      </div>
   </form>
</div>

<p>We will set up the site on Friday night from 17:00 to 19:00 hours.
   We need volunteers for this time also.
<div id='iVolunteered9HealthFairFriday'>
   <form id='healthfairform'
    onsubmit="alert('No longer taking volunteers'); return false;">
      <div style='border: 1px solid black; width: 45%; padding: 10px; background-color: red'>
         I want to volunteer for Friday Set-Up. Add my <input type='checkbox'
         name='spouse'/>Spouse as well

         <input type='hidden' name='event'
               value='9HealthFair Friday SetUp' />
         <input type='submit' value='Volunteer Now' />
      </div>
   </form>
</div>

</p>

<p>On Friday morning from 7:30 to 9:00 hours volunteers can get their
   blood drawn so you will not have to worry about it on Saturday.</p>

<p>Remember the 9HealthFair is one of our <b>biggest</b> events and
one that means a great deal to our local community. Granby needs your
support, so please volunteer.</p>

<div id='volunteerList'>

   <p>Toni Russell has made the following 9Health Fair volunteer
      assignments: </p>

   <pre
style='width: 35%; background-color: #FEF0C9; margin-left: 10px; padding: 20px'>
                 Blood Draw 4/18
Audrey Jennings         Peg Steffen           Mikel Tennant
Brene Belew-LaDue       Jennifer Neumann      Irmgard Mannix
Jesse Gatewood          Gail VanBocken        Darren Zunno   
Diane Marsch            Tarish Cessna

                 Centrifuge/cent. runner
Kim Long                Will Arduino          Matt Raynak
Tawnya Bailey           James Bateman

                 Ht/Wght/body mass/body fat screening
Nancy Stuart            Tom Chaffin

                 Health Professionals
Dr. Michael Muftic      Dr. Dan Fahrenholtz   Dr. Tim Bohlender

                 Hearing Screening
Jeff Shaw

                 Traffic Control/Usher
Frank Delay             Jason Schroer         Travis Beckham
Thomas Baumgarten       Peter Kerswell        Pat Berger
Dave Penny              Jack Bakken

                 Registration
Jan Knisley             Patrick Brower

                 Pre-Registration
Wendy Mielke            Sharon McCoy

                 Colon Cancer Screening
Tim Schowalter

                 Paperwork at Blood Draw
Glen McCoy

                 Cashiers
Audrey Walker           Sheri Lock            Bonnie Haddock
Martha Jane Blaine      Leslie Schroer

                 Form Check
Hope Bakken

                 Check Out
Barton Phillips         Ingrid Phillips

                 Volunteer Break Room
Jusy Schowalter

                 Blood Draw Nourishment
Monte Roberts

                 Coorinators/floats
Dorri Penny             Toni Russell          Ray Jennings

</pre>

</div>

<p>Patrick Brower has provided more information in the <a
href='newsletters/mar26-2009.php#9healthfair'>March 26
   newsletter</a>.</p>

<hr/>

<h2>March 30 Noon Board Meeting</h2>

<p>The board meeting was held at Edward Jones in Granby. The following
   persons attended:
   <ul>
      <li>Tim Schowalter</li>
      <li>Jan Knisley</li>
      <li>Rhonda Farrell</li>
      <li>Jack Bakken</li>
      <li>Barton Phillips</li>
      <li>Jeff Shaw</li>
      <li>Frank DeLey</li>
      <li>Mark Krieg</li>
   </ul>
   The result of the meeting will be discussed at the Wednsday noon (April
   8<sup>th</sup>) Bussiness meeting.
</p>

<hr/>

<h2>Rocky Mountain Repetory Theater (RMRT)</h2>

<a href='http://www.rockymountainrep.com'><img
src='/images/RMRT_top.jpg' alt='RMRT Logo' width='500' /></a>
<p>Also at the Feb. 25 club meeting Carrol Wolf discussed the upcoming
   summer season and the progress toward a new play house, the &quot;Raise
   the Curtain&quot; project.</p>

<p>The season's shows are:
   <ul>
      <li>Brigadoon</li>
      <li>Pirates of Penzance</li>
      <li>All Shoo Up</li>
      <li>The Andrews Brothers</li>
   </ul>
   Season tickets go on sale this Monday, and the first show is Friday
   June 12 (Brigadoon).</p>
<p>RMRT also sponsers the &quot;Youth Theater Program&quot;
   <ul>
      <li>Age 8-10: July 8-10</li>
      <li>Age 11-13: July 14-August 3</li>
      <li>Age 14-August 10</li>
   </ul>
   For more information on any of their programs check out <a
   href='http://www.rockymountainrep.com'>http://www.rockymountainrep.com</a></p>

<hr/>

<h2>Winter Park Club's Award Dinner Saturday Evening April 4th 2009</h2>

<p>This is an email from the Winter Park Club:</p>
<pre style='font-size: 12pt;'>
   Greetings fellow Winter Park-Fraser Rotarian's  (..and others copied on
this email as well!)

I wanted to take this opportunity to echo an earlier email reminder from
our incoming Club President Steve Radcliffe (who, BTW, has done an
outstanding job organizing this year's Award dinner!) about getting the
word out of our Club's Award Dinner which now less than a month way!

You can send the below link to any one you think might have an interest in
attending.

This link outlines all the details of the event--including places to stay
at the bottom of the page..

<a
href='http://winterparkfraserrotary.org/banquet09.html'>http://winterparkfraserrotary.org/banquet09.html</a>

Please email this to friends in the Valley or at other Rotary Clubs and
lets get the word out about what promises to be a great time..

Its also a great opportunity to recognize the work of 2 outstanding
members of our community and to celebrate the last few weeks of the 2009
ski season..

Respectfully,

Dan Lubar
Slopeside Internet
</pre>

<p>To make reservation email <a
href='mailto:ridgecliffe@msn.com?subject=Reservation For Awards Dinner'>Steve Radcliffe</a>.</p>

<hr/>

<h2>March 25 Noon Meeting</h2>

<p>Barton Phillips presented a visual demonstration of the new web
   site.</p>

<hr/>

<h2>March 18 Noon Meeting</h2>

<p>New honorary member Jynnifer Pierro (Granby Mayor) introduced
   herself to the members. She reviewed some of the projects underway
   in Granby. The new Gazebo in the park next to the Town Hall is
   being planned and is hoped to be complete in time for the Fourth of
   July. The new Gazebo replaced the Rotary funded Gazebo that was
   destroyed by winter snows. Jynnifer is enthusiastic and looking
   forward to her term as Mayor.</p>

<p>New member Nancy Karas introduced herself also. She is the
   Superintendent of Schools. She is looking forward to our support as
   she works to make our schools second to none. Good luck Nancy.</p>

<p>So far we have only 17 volunteers for the 9HealthFair. To volunteer
   and find out more about the fair and what we can do see the section
   <a href='#9HealthFair'>below.</a></p>

<p>Jan Knisley (President Elect) reviewed the PETS conference and her
   trip to Borneo. </p>

<p>Next week Barton Phillips will present a live demonstration of our
   new web site. If you are reading this then you already have had a
   taste of the site. Don't miss this informative presentation.</p>

<hr/>

<h2>Ecuador Project</h2>

<a href='http://escuelaminga.org'><img
src='/images/ecuadorproject.jpg' alt='Minga logo' width='400' /></a>

<p>Pam Gilbert and Eden Recor reviewed the status of <b>Centro
   Educativo La Minga</b>. &quot;Minga&quot; is a Quechua word which
means &quot;barn raising&quot;. The project has built a school,
irrigation, and sanitation facilities.</p>

<p>The community of Malingua Pamba volunteered and provided all the
labor for free in order to build their first, secondary school house.
The money and materials for the building were provided by the generous
donations of contributors and volunteers like you.</p>

<p>Pam has a couple of interesting news letters on her<a
   href='http://escuelaminga.org'> web site.</a>

   <div style='overflow: hidden; width: 100%;'>
<img src='/images/pamgilbert.jpg' alt='Photo of Pam' width='200'
     style='float: left;'
     /><br/><span style='color: blue; font-size: 10pt;'>
Pam is on the right.</span>
</p>

<address>
   Centro Educativo La Minga, Inc.<br/>
   P.O. Box 1877<br/>
   Granby, CO 80446<br/>
   Email: <a
   href='mailto:gilbertp0012@yahoo.com'>gilbertp0012@yahoo.com</a>,
   Web Page: <a
   href='http://escuelaminga.org'>http://escuelaminga.org</a>
</address>
   </div>

<hr/>

<h2>The Granby Rotary Club has a new domain name and ISP</h2>

<p>The Granby Rotary Club has a new domain name: www.granbyrotary.org.
   The site has also been reworked and has a new look and feel. The
   site is now hosted by <a href="http://www.lamphost.net">Lamphost</a> a
   full feature Internet Service Provider (ISP) that features a full
   LAMP (Linux, Apache, MySql, PHP/python/perl) environment that
   allows state of the art dynamic Web pages.</p>
<p>Over the next few months new features will be added to the site
   which hopefully will make the site more appealing and useful to the
   Rotary members and community.</p>
<p>If you have any suggestions, comments, or fixes please email them
   to <a href="mailto:info@granbyrotary.org">info@granbyrotary.org</a></p>

<hr/>

<h2>New Feature, <span class="button"><a href="bboard.php">Bulletin Board</a></span></h2>

<p>You may have noticed a new red button on the home page that says
   <b>Bulliten Board</b>. This feature lets members place messages
   that can be read by all members. To access the bulliten board you
   will need to be a member of the Granby Rotary Club. The first time
   you click on the button you will be asked to enter your email
   address. This email address will be checked against the address in
   the members database. Once a match is confirmed a web browser
   <i>COOKIE</i> is set so you will not have to enter your email
   again.</p>
<p>Please feel free to test this feature by entering a message.
   The messages will remain on the board for one week.</p>
<p>Please give your <a
href='mailto:info@granbyrotary.org'>feedback</a> and any suggestions
   about this feature.</p>

<hr/>
<h2>HR 1451 Presentation</h2>
<p>During the Jan. 28 meeting Deb Ruttenbur presented a review of
   House Bill 1451. Deb's contact information follow: </p>
<p>
Deb DeLap Ruttenberg, M.S.W.<br/>
Grand County House Bill 1451 Coordinator<br/>
Juvenile Services Department<br/>
970.531.6479 (c)<br/>
970.887.7337 (p)<br/>
druttenberg@co.grand.co.us
</p>

<hr/>
<h2>Monday Feb. 2 Board Meeting</h2>
<p>The board met at Edward Jones in Granby at 12 noon on Monday Feb. 2.
   The following items of interest:</p>
<ul>
   <li>Fellowship Feb. 20. Sign up by Feb 11. Still need more
      donations for the silent auction.</li> 
   <li>Jack Bakken will talk to the Kremmling Rotary Club about the
      Dolly Parton Imagination Library on Wed. night Feb 11.</li>
   <li>The Health Fair is scheduled for April 18, and the next meeting
      of the committee is Feb. 12, 1 to 3 PM at EMS</li>
   <li>Group Study Exchange (GSE) New Zealand will retreat at Grand
      Lake April 25 through 27. Dinner and talk April 26</li>
   <li>Scholarships: due March 1, present May 29</li>
   <li>District Conference May 1 through 3 in Colorado Springs</li>
   <li>Club Leader Training June 6</li>
</ul>
<p>The board meeting will be discussed at the Feb. 11 Luncheon Business
   Meeting.</p>
<p>Other big news on the Polio front, the Gates Foundation will donate
   another $225 million to Rotary for their Polio project. Rotary will
   have to provide a matching $100 million. Further new and discussion
   at the February 11 meeting here in Granby.</p>

<hr/>
<?php
$gr->footer();
unlink("/tmp/oldnews.i.php");
?>
</body>
</html>
