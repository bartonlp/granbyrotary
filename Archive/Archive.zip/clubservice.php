<?php
require_once("/home/bartonlp/includes/granbyrotary.conf");
$gr = new GranbyRotary;
?>
<head>
   <title>Service Projects</title>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
   <meta name="Author"
      content="Barton L. Phillips, mailto:barton@granbyrotary.org"/>
   <meta name="description"
      content="Name: Rotary Club of Granby Colorado, Page: Services Projects"/>
   <meta name="keywords" content="rotary"/>

   <!-- FAVICON.ICO -->
   <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />

   <!-- Link our custom CSS -->
   <link rel="stylesheet" title="Rotary Style Sheet"
        href="/css/rotary.css" type="text/css"/>

   <!-- Scripts -->
   <script type="text/javascript"
            src="/js/jquery-1.3.2.min.js"></script>

   <script type="text/javascript" src="/js/rssnews.js"></script>

   <script type="text/javascript">
jQuery(document).ready(function($) {
  // Only get twenty days of feed not all of it
  $("#news-feed").newsFeed("/proxy.rss.php?feed=http://feeds2.feedburner.com/rotary/PBqj", 20);
});
   </script>

   <style type="text/css">
/* News Feed -- See rssnews.js for more info on classes */

#news-feed {
        position: relative;
        /* this height must match the value in .headline below */
        height: 200px; 
        width: 100%;
        overflow: hidden;
        background-color: pink;
        border-top: 1px solid red;
}

.headline {
        position: absolute;
        /* this hight must match above. */
        height: 200px;
        /* this is height + 2*padding below + anything else you might add! */
        top: 210px;
        overflow: hidden;
        padding: 0 5px;
}
#news-feed h4 {
        margin-top: .5em;
        margin-bottom: .25em;
        font-size: 1em;
}
#news-feed h4 a {
        color: #006;
}
#news-feed .publication-date {
        margin-bottom: 1em;
        font-style: italic;
}
.news-wait {
        position: absolute;
        top: 30%;
        left: 50%;
        margin-left: -10px;
        z-index: 4;
}

.fade-slice {
        position: absolute;
        width: 100%;
        height: 2px;
        background-color: #efd;
        z-index: 3;
}

#wrapper {
        float: right;
        width: 25%;
        border: 1px solid white;
        margin-right: 20px;
}
   </style>       

</head>

<body>

<?php
$gr->header("<h2>Club Service Projects</h2>");
if($gr->id != 0) {
  print("
<h3 id='loginMsg'>Welcome $gr->GrUser.</h3>
<hr/>
");
} else {
  echo <<<EOF
<h3 id='loginMsg'>If you are a Granby Rotary Member please <a href='/login.php?return=$_SERVER[PHP_SELF]'>Login</a> at this time.<br/>
There is a lot more to see if you <a href='/login.php?return=$_SERVER[PHP_SELF]'>Login</a>!
</h3>
<p style='text-align: center'>Not a Grand County Rotarian? You can <b>Register</b> as a visitor.
<a href="/login.php?return=$_SERVER[PHP_SELF]&visitor=1">Register</a></p>

<hr/>

EOF;
}
?>

<h2>Youth Programs</h2>

<ul>
   <li>The Club sponsors the Boy Scout troop and Cub Scout Pack</li>
   <li>The Club sponsors up to four annual scholarship
      awards to Middle Park High School students.</li>
   <li>The Club also sends one or two qualified student to
      the <a href='http://rmryla.org/'>District Rotary Youth Leadership
      Award</a> conference each year.</li>
   <li>The Club sponsors a foreign Rotary
      Youth Exchange student on a annual basis.</li>
   <li>The Club support the School-to-Work project, and other enrichment programs for local youth.</li>
   <li>The Club buys dictionaries for all third grader&apos;s in the county,
      in partnership with the Grand Lake and Winter Park/Fraser Valley Rotary Clubs</li>
</ul>

<hr/>

<a name='rotaryint'></a>

<h2>Rotary International Programs</h2>

<div id="wrapper">
   <p style="text-align: center">Rotary International New Feed</p>
   <div id="news-feed">
   </div>
</div>

<ul>
  <li>The Club hosts a Group Study Exchange team
  from another District almost every year.</li>
  <li>Members contribute to the Rotary Foundation,
  which supports many world-wide humanitarian services, including
  PolioPlus.<br/>
<img src='images/endpolionow.jpg' /><br/>

<object width="445" height="364"><param name="movie"
value="http://www.youtube.com/v/tH1vPTVGHOk&hl=en&fs=1&border=1"></param><param
name="allowFullScreen" value="true"></param><param
name="allowscriptaccess" value="always"></param><embed
src="http://www.youtube.com/v/tH1vPTVGHOk&hl=en&fs=1&border=1"
type="application/x-shockwave-flash" allowscriptaccess="always"
allowfullscreen="true" width="445" height="364"></embed></object>

<object width="445" height="364"><param name="movie"
value="http://www.youtube.com/v/E1mnSKs2bqA&hl=en&fs=1&border=1"></param><param
name="allowFullScreen" value="true"></param><param
name="allowscriptaccess" value="always"></param><embed
src="http://www.youtube.com/v/E1mnSKs2bqA&hl=en&fs=1&border=1"
type="application/x-shockwave-flash" allowscriptaccess="always"
allowfullscreen="true" width="445" height="364"></embed></object>

</li> </ul>

<hr/>

<h2>Community Service Grants</h2>
<ul>
  <li>Little League</li>
  <li>MPHS After-Prom Party</li>
  <li>Granby Elementary PAC</li>
  <li>Adopt-a-Hightway (five miles on US-40 &amp; US-34)</li>
  <li>Granby Library Summer Reading Program</li>
</ul>

<hr/>
<h2>Granby Skate Park &amp; Panther Den</h2>

<p>The Club joined in partnership
with the Town of Granby to develop the Granby Skate Park, a facility
for local youth and adults who enjoy skateboarding and rollerblading
activities. Members were involved in the planning and installation
of park improvements, and in fund raising activities to pay the
costs of such improvements. We also volunteered labor and
materials to renovate the Town building now known as the &quot;Panther
Den&quot;, a fun and healthy place for local youth to get together.</p>

<hr/>

<h2>Adopt-A-Highway</h2>

<p>We have adopted approximately five miles of
local highway for semiannual pick-up responsibility.
</p>

<hr/>

<h2>Fourth of July Barbeque</h2>
<p>The Club also serves a lunch in the Town
Park following the Granby 4th of July parade.
</p>

<hr/>
<h2>Anniversary Party - Silent Auction</h2>

<p>The Club hosts an annual anniversary party
  each year, which may includes a banquet and silent auction fundraiser.
</p>

<hr/>

<h2>Member Fellowship</h2>

<ul>
  <li>Dinners, parties and holiday activities</li>
  <li>Rotary District 5450 service conferences</li>
  <li>Visits to and joint events with neighbor
  Rotary Clubs</li>
  <li>Attend Rotary International conventions</li>
</ul>
      
<hr/>
<?php
$gr->footer();
?>
</body>
</html>
