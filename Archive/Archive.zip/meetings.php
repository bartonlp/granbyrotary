<?php
require_once("/home/bartonlp/includes/granbyrotary.conf");

$gr = new GranbyRotary;
$self = $_SERVER['PHP_SELF'];

$HeadDesc = $HeadTitle = "Meeting Programs";

ob_start();
include($HeadFile);
$PageHead = ob_get_clean();

if(!$_GET['print']) {
  $style = <<<EOF
   <link id="defaultcss" rel="stylesheet" title="Rotary Style Sheet"
        href="/css/rotary.css" type="text/css" media="screen" />

EOF;
} else {
  $style = <<<EOF
   <link id="printcss" rel="stylesheet" href="/css/print.css"
       type="text/css" title="print" media="print" />

EOF;
}

$script = <<<EOF
   <script type="text/javascript">
jQuery(document).ready(function($) {
  $("#print").html("<input type='image' id='printbtn' src='/images/print.gif' style='width: 100px'/>");
  $("#printbtn").click(function() {
    var w = window.open("/meetings.php?print=1", "Print", "width=800, height=600, menubar=yes,\
      scrollbars=yes, resizable=yes");
  });
});
   </script>

EOF;
$style .= <<<EOF
<style type='text/css'>
#assignments {
        border: 1px solid black;
        background-color: white;
}
#assignments table {
        width: 100%;
}
#assignments * {
        border: 1px solid black;
        font-size: 90%;        
}
#assignments td {
        padding: 5px 10px;
}
.bis {
        font-style: italic;
        font-weight: bold;
}
.date {
        color: red;
}
   </style>

EOF;

$PageHead = preg_replace("/<!-- Script for this page -->/", $script, $PageHead);
$PageHead = preg_replace("/<!-- Styles for this page -->/", $style, $PageHead);

echo <<<EOF
$PageHead
<body>

EOF;

if($date = $_GET['date']) {
  Edit($date);
} elseif($_GET['print']) {
  PrintIt();
} elseif($date = $_POST['post']) {
  Post($date);
} else {
  Show();
}

echo <<<EOF
<hr/>

<p>If you have conflicts with the schedule, please arrange a change of date with
  another member and notify Barton Phillips at 970-877-3696 or
  <a href='mailto:bartonphillips@gmail.com'>bartonphillips@gmail.com</a>
  or <a href='mailto:barton@bartonphillips.org'>barton@bartonphillips.org</a>
  or <a href='mailto:info@granbyrotary.org'>info@granbyrotray.org</a>
</p>

<hr/>

EOF;

$wc3val = <<<EOF
<!-- WC3 Validation for XHTML -->
<p>
   <a href="http://validator.w3.org/check?uri=referer"><img
   src="/images/valid-xhtml10.png"
   alt="Valid XHTML 1.0 Strict"
   style='height: 31px; width: 88px; border: 0'/></a>

   <a href="http://jigsaw.w3.org/css-validator/check/referer">
      <img style="border:0;width:88px;height:31px"
             src="http://jigsaw.w3.org/css-validator/images/vcss"
             alt="Valid CSS!" />
   </a>
</p>
EOF;
$gr->footer($wc3val);

echo <<<EOF
</body>
</html>
EOF;

// END OF MAIN
// ---------------------------------------
// FUNCTIONS

// Show

function Show() {
  global $self, $gr;
  
  $gr->header("<h2>Program Assignments</h2>");

  if($gr->id != 0) {
    echo <<<EOF
<h3 id='loginMsg'>Welcome $gr->GrUser.</h3>
<hr/>

EOF;
  } else {
    echo <<<EOF
<h3 id='loginMsg'>If you are a Grand County Rotarian please <a href='/login.php?return=$_SERVER[PHP_SELF]'>Login</a> at this time.<br/>
There is a lot more to see if you <a href='/login.php?return=$_SERVER[PHP_SELF]'>Login</a>!
</h3>
<p style='text-align: center'>Not a Grand County Rotarian? You can <b>Register</b> as a visitor.
<a href="/login.php?return=$_SERVER[PHP_SELF]&visitor=1">Register</a></p>

<hr/>

EOF;
  }

  echo <<<EOF
<div>
<p>You can edit the assignments that belong to you. If there is an <b>EDIT</b> link in the <i>Editable</i> field
you can click on it and change the fields. Here is what you can do:
<ul>
<li>Change you <b>Status</b> to &quot;confirmed&quot;. Once you do this, even if you do not have a subject yet,
the email &quot;Heckling&quot; will stop!</li>
<li>If you have someone who is doing the presentation for you
you can change the name to that persion's name. <b>The assignment still belongs to you however</b></li>
<li>You can update the subject field</li>
<li>You can add a link to a page that describes the talk.</li>
</ul>
If you need to get someone else to do the assignment please contact
<a href='/email.php?id=25&subject=Can+Not+Do+Talk+HELP'>Barton</a>! Also, if you can't come up with a presentation please
contact <a href='/email.php?id=25&subject=HELP+finding+a+presenter'>Barton</a> as we have several orginizations that
would like to give our group a presentation.</p>
<p>If you would like to sign up for future dates please contact <a href='/email.php?id=25&subject=Talk+Signup'>Barton</a>
or <a href='/email.php?id=16&subject=Talk+Signup'>Jan</a>.</p>

<div id="print">
<a href="$self?print=1"><img src="/images/print.gif" width="100" alt="print logo"/></a>
</div>

<table id='assignments'>
<thead>
<tr><th>Date</th><th>Owner</th><th>Status</th><th>Presenter</th><th>Subject</th><th>Editable</th></tr>
</thead>
<tbody>
EOF;
  
  $results = $gr->query("select r.id,date,yes,name,subject,type,FName,LName from meetings as m
left join rotarymembers as r on r.id=m.id where date_add(date, interval 1 day) > now() order by date");
  
  while($row = mysql_fetch_assoc($results)) {
    extract($row);

    $yes = preg_replace("/-/", " ", $yes);
    switch($type) {
      case 'business':
        $name = "<span class='bis' style='border: 0'>Business Meeting</span>";
        if($subject == "") {
          $subject = "various";
        }
        break;
      case 'open':
        $name = "<span style='color: red; border: 0'>OPEN DATE</span>";
        break;
      case 'none':
        $name = "<span style='color: green; border: 0'>NO MEETING</span>";
        $subject = "No Meeting on this date";
        break;
      case 'speaker':
        break;
    }

    if(($id == $gr->id && $gr->id != 0) || ($gr->id == ID_BARTON)) {
      $edit = "<a href='$self?date=$date'>EDIT</a>";
    } else {
      $edit = "";
    }
    echo <<<EOF
<tr><td class='date'>$date</td><td>$FName $LName</td><td>$yes</td><td>$name</td><td>$subject</td><td>$edit</td></tr>

EOF;
  }
  echo <<<EOF
</tbody>
</table>


EOF;

}

//--------------------
// Edit

function Edit($date) {
  global $self, $gr;

  $results = $gr->query("select m.*, r.FName, r.LName from meetings as m
left join rotarymembers as r on m.id=r.id where m.date='$date'");

  // $id is the member's id that is responsible for the presentation

  $row = mysql_fetch_assoc($results);
  extract($row);

  $gr->header("<h2>Edit Your Program Assignment</h2>");

  $options = array('not confirmed', 'confirmed', 'can-not');
  
  echo <<<EOF
<h3>Responsible Member: $FName $LName</h3>
<p>$FName if you know your subject and who will be doing the presentation please fill in those items.
If you do not yet have a subject etc. but you <b>will</b> be doing the presentation, please select <b>confirmed</b>
from the <b>Status</b> drop down. If you feel you can't give the presentation or find a presenter please
select <b>can-not</b> from the <b>Status</b> drop down. If you do select <b>can-not</b> an email will
be sent to Barton Phillips so he can try to find a replacement speaker. Thanks</p>

<form action="$self" method="POST">

<table style="width: 95%">
<tr><th>Date</th><td>$date</td></tr>
<tr><th>Status</th><td><select name='status'>

EOF;

for($i=0; $i < count($options); ++$i) {
  $opt = $options[$i];
  echo "<option value='$opt'" . ($yes == $opt ? " selected" : "") . ">$opt</option>\n";
}
  echo <<<EOF
</select>
</td></tr>
<tr><th>Name</th><td><input type="text" name="name" value="$name" />
<span style="color: gray; font-size: 8pt">this can be another person who is presenting for the  member</span></td></tr>
<tr><th>Subject</th><td><input type="text" style="width: 100%" name="subject" value="$subject" /></td></tr>

EOF;

  // Let me edit the additional fields

  if($gr->id == ID_BARTON) {

    $result1 = $gr->query("select id as memberId, concat(FName, ' ', LName) as name from rotarymembers where status='active'");

    echo <<<EOF
<tr><th>ID</th>
<td><select name="blp_id">
<option value='-1'>-1: Open</option>
<option value='0'>0 : Business Meeting</option>

EOF;

  while($row = mysql_fetch_assoc($result1)) {
    extract($row);
    // $id is the member who is responsible

    echo "<option value='$memberId'" . ($memberId == $id ? " selected" : "") . ">$memberId : $name</option>\n";
  }
  echo <<<EOF
</select>
</td>
</tr>
<tr><th>Type</th><td><select name="type">

EOF;
  $types = array('speaker','business','none', 'open');
  for($i=0; $i < count($types); ++$i) {
    $opt = $types[$i];
    echo "<option value='$opt'" . ($type == $opt ? " selected" : "") . ">$opt</option>\n";
  }
  echo <<<EOF
</select>
</td></tr>

EOF;
  } // end ID_BARTON

  echo <<<EOF
</table>
<input type="submit" value="Submit Changes" />
<input type="hidden" name="post" value="$date" />
<input type="hidden" name="id" value="$id" />
</form>

EOF;
}

// FUNCTION
// Post

function Post($date) {
  global $self, $gr;

  extract($_POST);

  // If I am editing then blp_id is set and use it rather than id

  if($blp_id) {
    //echo "<br>blp_id=$blp_id<br>";
    $id = $blp_id;
  }
  // $id here is the member who is responsible

  $gr->header("<h2>Post Updated to Program Assignment</h2>");

  switch($id) {
    case 0:
      $membername = "(The Board)";
      break;
    case -1:
      $membername = "(OPEN SLOT)";
      break;
    default:
      $results = $gr->query("select concat(FName, ' ', LName) as membername from rotarymembers where id='$id'");
      $row = mysql_fetch_assoc($results);
      extract($row);
      break;
  }

  $emailsubject = stripslashes($subject);

  if($gr->id != ID_BARTON) {
    if($status == "can-not") {
      $message = "$membername: talk on $date.";
      mail("bartonphillips@gmail.com", "Meetings: Can Not", $message, 'from: info@granbyrotary.org');
      echo <<<EOF
<h3>An Email has been sent to Barton Phillips informing him that you CAN NOT do the talk.</h3>
<p>Please try to think of someone who can do the talk. Barton will get back to you ASAP.</p>

EOF;
    } elseif($status == "confirmed") {
      $message = "$membername: talk on $date. Subject: $emailsubject, Presenter: $name";
      mail("bartonphillips@gmail.com", "Meetings: confirmed", $message, 'from: info@granbyrotary.org');
    } else {
      // status say "not-confirmed"
      // check if the subject has been added or a new name or a link. If so set status to
      // confirmed.
      // Else scold the member and tell him to do something!
      if(!empty($subject)) {
        $status = "confirmed";
        echo <<<EOF
<p>You have changed the <b>Subject</b> field but not set the <b>Status</b>.
That is OK. I have set the status to <b>confirmed</b> you will have someone give a talk. If this is not correct
please return to the edit page and fix it.</p>

EOF;
      $message = "$membername: talk on $date. Subject: $emailsubject, Presenter: $name";
      mail("bartonphillips@gmail.com", "Meetings: confirmed", $message, 'from: info@granbyrotary.org');

      } elseif($name != $membername) {
        $status = "confirmed";
        echo <<<EOF
<p>You have changed the <b>Name</b> field to the name of the presenter but have not added a subject yet.
That is OK. I have set the status to <b>confirmed</b> you will have someone give a talk. If this is not correct
please return to the edit page and fix it.</p>

EOF;
        $message = "$membername: talk on $date. Subject: $emailsubject, Presenter: $name";
        mail("bartonphillips@gmail.com", "Meetings: confirmed", $message, 'from: info@granbyrotary.org');
      } else {
        // member has not confirmed or set the name or subject. He
        // needs to do something.
        echo <<<EOF
<p>It looks like you have not done anything? You should either change the <b>Status</b>, <b>Name</b>, or <b>Subject</b>.
Please re-edit the page. <a href="$self?date=$date">Return to Edit Page</a></p>

EOF;
        exit();
      }
    }
  }

  $subject = htmlspecialchars($subject);

  // If me update the type and id

  if($gr->id == ID_BARTON) {
    //echo "<br>ID=$id<br>\n";
    //exit();
    $gr->query("update meetings set yes='$status', name='$name', subject='$subject', type='$type', id='$id' where date='$date'");
  } else {
    $gr->query("update meetings set yes='$status', name='$name', subject='$subject' where date='$date'");
  }
  echo "<p>Return to <a href='$self'>Meetings</a></p>\n";
}

// PRINT

function PrintIt() {
  global $self, $gr;

  echo <<<EOF
<table id='assignments'>
<thead>
<tr><th>Date</th><th>Name</th><th>Subject</th></tr>
</thead>
<tbody>
EOF;
  
  $results = $gr->query("select * from meetings where date_add(date, interval 1 day) > now() order by date");
  while($row = mysql_fetch_assoc($results)) {
    extract($row);

    if($type == "business") {
      $name = "<span class='bis' style='border: 0'>Business Meeting</span>";
      if($subject == "") {
        $subject = "various";
      }
    }
    echo <<<EOF
<tr><td>$date</td><td>$name</td><td>$subject</td></tr>

EOF;
  }
  echo <<<EOF
</tbody>
</table>

EOF;
exit();
}

?>
