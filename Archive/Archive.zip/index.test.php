<?php
require_once("/home/bartonlp/granbyrotary.org/htdocs/rotary.new.i.php");

$S = new GranbyRotary;

if(isset($_GET[memberid])) {
  $mid = $_GET[memberid];

  // The member is responding to an email with the query ?memberid=id
  // Set the member cookie
  $S->SetIdCookie($mid); // This sets the browser's cookie but not php's $_COOKIE
  $_COOKIE[GrId] = $mid;  // force $_COOKIE[GrId] to be $mid so we can set everything with CheckId!!!
  $S->CheckId();  // sets all of the GXxxx publics
}
  
$NewBBmsg = $S->CheckBBoard(); // Check if new BB posts

// check if there is mail waiting in info@granbyrotary.org

$mbox = imap_open("{granbyrotary.org/imap/notls:143}INBOX", "info@granbyrotary.org", "rotary7098653");
if(!$mbox) {
  echo "Error opening mail box<br>\n";
} else {
  $checkInfo = imap_mailboxmsginfo($mbox);

  $mbox = imap_open("{granbyrotary.org/imap/notls:143}INBOX", "webmaster@granbyrotary.org", "rotary7098653");
  if(!$mbox) {
    echo "Error opening mail box<br>\n";
  } else {
    $checkWebmaster = imap_mailboxmsginfo($mbox);
  }
}

$extra = <<<EOF
   <!-- News Rotator -->
   <script type="text/javascript" src="/js/rotator.js"></script>

   <script type="text/javascript">
jQuery(document).ready(function($) {
  $("#child").hide();
  
  $("#parent").toggle(function() {
    $("#child").show();
  }, function() {
    $("#child").hide();
  });

});
   </script>

   <!-- CSS for News Rotator -->
   <link rel="stylesheet" href="/css/rotator.css" type="text/css"/>
   <style type="text/css">
#loginMsg {
        text-align: center;
}
#loginMsg a {
        font-variant: small-caps;
        font-size: x-large;
}
#wrapper {
        float: right;
        width: 50%;
        border: 1px solid white;
        margin-right: 10px;
}
/* link buttons */
#linkbuttons {
        border: 0;
/*        width: 280px; */
        width: 30%;
        margin-top: 30px;
        margin-bottom: 30px;
}
/* class button is also in rotary.css so check there too if thing change */
.button {
        border: 4px outset gray; 
        text-align: center;
        background-color: red;
        color: white;
        cursor: pointer;
}
.button a {
        color: white;
}
/* style for drop down */
#rotarylinks  {
        border: 0;
        width: 25%;
        margin-left: auto;
        margin-right: auto;
        margin-top: 30px;
        margin-bottom: 30px;
}
#parent {
        cursor: pointer;
        margin: 0;
}
#child {
        display: inline;
}
#child a {
        border: 1px solid black;
        display: block;
        padding: 2px 5px;
        background-color: white; /* #FFFFEE; */
}
/* Whos Been Here */
#todayGuests, #todayGuests * {
        background-color: white;
        border: 1px solid black;
}
#todayGuests * {
        padding: 5px;
}
   </style>

EOF;

// Check if a member  

if($S->id != 0) {
  // MEMBER

  $memberOrLogin = <<<EOF
<h3 id='loginMsg'>Welcome $S->GrUser.</h3>
EOF;
} else {
  // NOT A MEMBER OF NOT LOGGED IN

  $memberOrLogin = <<<EOF
<h3 id='loginMsg'>If you are a Grand County Rotarian please
<a href='/login.php?return=$_SERVER[PHP_SELF]'>Login</a> at this time.<br/>
There is a lot more to see if you <a href='/login.php?return=$_SERVER[PHP_SELF]'>Login</a>!
</h3>
<p style='text-align: center'>Not a Grand County Rotarian? You can <b>Register</b> as a visitor.
<a href="/login.php?return=$_SERVER[PHP_SELF]&amp;visitor=1">Register</a></p>
EOF;
}
$h->title = "Rotary Club of Granby CO.";
$h->extra = $extra;
$h->banner = <<<EOF
      <p>PO Box 1430<br/>
      Granby, CO 80446<br/>
      e-mail:
      <a href='mailto:info@granbyrotary.org'>info@granbyrotary.org</a><br/>

      Meets Wednesday 12:00 PM at<br/>
      <a href='http://www.mavericksgrille.com/'>Maverick's Grille</a><br>
      15 E. Agate Avenue (US Highway 40)<br>
      Granby, Colorado 80446<br>
      Phone: (970) 887-9000<br>
      <a href='/about.php#MapToMeetingPlace'>Map</a>
      </p>
      <a name='callin'></a>
$memberOrLogin
EOF;
$h->daycountwhat = 'all';

$top = $S->getPageTop($h);

$wc3val = <<<EOF
<p style='text-align: center;'><a href='/aboutwebsite.php'>About
   This Site</a></p>
<p style="text-align: center">
<a href="http://feeds2.feedburner.com/http/wwwgranbyrotaryorg"
title="Subscribe to my feed" rel="alternate"
type="application/rss+xml"><img
src="http://www.feedburner.com/fb/images/pub/feed-icon32x32.png"
alt="" style="border:0"/></a><a
href="http://feeds2.feedburner.com/http/wwwgranbyrotaryorg"
title="Subscribe to my feed" rel="alternate"
type="application/rss+xml">Subscribe in a reader</a>
<br/>
or<br/>
<a
href="http://feedburner.google.com/fb/a/mailverify?uri=http/wwwgranbyrotaryorg&amp;loc=en_US">Subscribe
to Granby Rotary Club by Email</a>
</p>
<!-- WC3 Validation for XHTML -->
<p style='text-align: center;'>
   <a href="http://validator.w3.org/check?uri=referer"><img
   src="/images/valid-xhtml10.png"
   alt="Valid XHTML 1.0 Strict"
   style='height: 31px; width: 88px; border: 0'/></a>

   <a href="http://jigsaw.w3.org/css-validator/check/referer">
      <img style="border:0;width:88px;height:31px"
             src="http://jigsaw.w3.org/css-validator/images/vcss"
             alt="Valid CSS!" />
   </a>
</p>
EOF;

$footer = $S->getFooter($wc3val);
$whosBeenHereToday = $S->getWhosBeenHereToday();

$presmsg = getPresMsg();

echo <<<EOF
$top
<p>The Rotary Club of Granby was chartered in 1987, and its membership includes men and women representing a wide cross-section of
local businesses and professions. The club meets each Wednesday for fellowship, lunch, and interesting and informative programs
dealing with topics of local and global importance.  </p>

<p>The club is part of Rotary District 5450, comprised of 51 clubs and over 3,000 members. The 2009-2010 Rotary District Governor
is <a href="http://www.rotary5450.org">Mike Oldham</a>.</p>
<hr/>
$presmsg
<table>
   <tr>
      <td style="width: 20%"><a href="http://www.endpolio.com?id=$S->GrDistrictId"><img
      src="images/endpolionow.jpg"
      alt="End Polio logo"
      title="End Polio"
      style="width: 100%" /></a></td>
      <td style="padding: 10px">District 5450 is dedicated to the Rotary International's
         <span style="color: red; font-size: 150%;">End Polio
         Now</span> campaign. The District <a href="http://www.endpolio.com?id=$S->GrDistrictId">End Polio</a>
         web site <a href="http://www.endpolio.com?id=$S->GrDistrictId">www.endpolio.com</a>
         gives you a change to donate and to
         <a href="http://www.endpolio.com/endpolio/site/invitefriends.php?id=$S->GrDistrictId">Invite
            Friends</a>.  If each member asks ten friends to donate just \$10 we will be able to meet our club's
         goal of raising \$100 per member.
      </td>
   </tr>
</table>
<hr/>
<div style="float: left">
<a href="http://www.facebook.com/group.php?gid=105501794053"><img
    src="/images/find_us_on_facebook_badge.gif"
  title="Find Us On Facebook"
    alt="find us on facebook" /></a>
</div>
<div style="float: right; width: 50%; margin-bottom: 10px; margin-right: 5px">
$whosBeenHereToday
</div>
<br style="clear: both"/>
<!-- News Feed -->
<div id="wrapper">
   <p  style="padding: 0 5px">
   <a href="/about.php#rotaryint">Rotary International News Feed</a></p>
   <hr/>
   <h4 style="padding: 0 5px;">Highlights from our <a href="/news.php">News Page</a></h4>
   <p style="padding: 0 5px;">Move the mouse over the story to stop it from scrolling.</p>

   <div id="news-feed">
      <a href="/news.php">News Releases</a>
   </div>
</div>

<!-- News Changed? and Bulletin Board Buttons and rotary links -->
<div id='linkbuttons'>

EOF;

// Has the News page changed since member was last here?

if($S->newsChanged()) {
  echo <<<EOF
<p class='button' onclick='location.href="/news.php";'>
<img src='/images/new.gif' alt='New' /><a href='/news.php'>Breaking News</a><br/>
<span style='font-size: 12pt; color: black;'>Since You Last Looked</span>
</p>

EOF;
}

// Has the member seen all the BB posts?

// Use the new.gif image as a way to put the user's id into the log
// files.

if($NewBBmsg) {
  echo <<<EOF
<p class='button' onclick='location.href="/bboard.php";'>
<a href='/bboard.php'>Bulletin Board $NewBBmsg</a>
</p>

EOF;
} else {
  echo <<<EOF
<p class='button' onclick='location.href="/bboard.php";'>

<a href='/bboard.php'>Bulletin Board</a>
</p>

EOF;
}

echo <<<EOF
<!-- Rotary Links -->
      
<p id='parent' class='button'>Links to Rotary Sites</p>

<div id='child'>
   <a  href="http://rotary5450.org/">District 5450 Web Site</a>
   <a  href="http://www.rotary.org/">Rotary International Web Site</a>
   <a  href="http://www.endpolio.com">District 5450 End Polio Campaign</a>
   <a  href='http://rmryla.org'>RYLA (Rotary Youth Leadership Award)</a>
   <a  href='http://WinterparkFraserRotary.org'>Winter Park Rotary Club</a>
   <a  href='http://www.grandlakerotary.org/'>Grand Lake Rotary Club</a>
   <a  href='http://www.kremmlingrotary.org'>Kremmling Rotary Club</a>
   <a  href='http://escuelaminga.org/Minga/Rotary.html'>The Equator Project</a>
   <!--http://www.rotary5450.org/admin/Areas/Area17.htm Mark Kreig
   Assistent Governer for area 17 -->
</div>
</div>

<br style="clear: both" />
<hr/>
<!-- Footer. Setup Footer text -->

EOF;

if($S->id == ID_BARTON) {   
  if($checkInfo->Unread) {
    // new mail in info@granbyrotary.org
    echo <<<EOF
<p>
<a href="/admin/ckemail.php?email=info@granbyrotary.org">
<img src='/images/new.gif' title="New Email at info@granbyrotary.org" alt='New Email Available'  style="border: 0"/>
</a> $checkInfo->Unread mail in info@granbyrotary.org </p>

EOF;
  }
  if($checkWebmaster->Unread) {
    echo <<<EOF
<p>
<a href="/admin/ckemail.php?email=webmaster@granbyrotary.org">
<img src='/images/new.gif' title="New Email at webmaster@granbyrotary.org" alt='New Email Available'  style="border: 0"/>
</a> $checkWebmaster->Unread mail in webmaster@granbyrotary.org </p>
EOF;
  }  
}
echo $footer;

// DONE  
   
function getPresMsg() {
  global $S;
  list($result, $n) = $S->query("select title, msg, date from presmsg where id='1'", true);
  if(!$n) return null;

  $row = mysql_fetch_assoc($result);
  extract($row);
  if(empty($title) || empty($msg)) return null;
  
  return <<<EOF
<div id="presmsg" style="width: 80%; margin: 0 auto 0 auto; background-color: pink; border: 1px solid red;">
<h2 style="text-align: center; background-color: lightgreen; margin: 0px; line-height: 50px">Message From Our President</h2>
<h3 style="text-align: center;">$title</h3>
<div style="padding: 5px;">$msg</div>
</div>
<hr>
EOF;
}

?>