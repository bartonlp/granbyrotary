<?php
// GranbyRotary Class 
require_once('rotary.i.php');

$gr = new GranbyRotary; // Use default DOCTYPE which is XHTML 1.0
// moved to constructor: $gr->loginInfo(); // log ip, agent etc.

$NewBBmsg = $gr->CheckUser(); // Check if new BB posts

// check if there is mail waiting in info@granbyrotary.org

$mbox = imap_open("{granbyrotary.org/imap/notls:143}INBOX", "info@granbyrotary.org", "rotary7098653");

if(!$mbox) {
  echo "Error opening mail box<br>\n";
}

$check = imap_mailboxmsginfo($mbox);

?>
<head>
   <title>The Rotary Club of Granby, Colorado</title>

   <!-- METAs -->
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
   <meta name="copyright" content="2009, Rotary Club of Granby Colorado" />
   <meta name="Author"
      content="Barton L. Phillips, mailto:barton@granbyrotary.org"/>
   <meta name="description"
      content="Name: Rotary Club of Granby Colorado, Page: Home Page"/>
   <meta name="keywords"
      content="Rotary, Granby, Grand County, Colorado, Grand County All-Club
         Email"/>

   <!-- Microsoft verification tag -->
   <meta name="msvalidate.01" content="769E2BFA62FFED5C91B7F4200CECA90A" />
   <!-- Google verification tag -->
   <meta name="google-site-verification" content="FtWTx_Hn0ie5lTF42jPm5zjVtsDtBFC1MC7kyDJ99AU" />
   <meta name="verify-v1"
      content="dgAIXuJJft+YWGYjqA2g/NbkCkbfkMdqtAjtx3E4nkc="/>

   <!-- FAVICON.ICO -->
   <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
   
   <!-- RSS FEED -->
   <!--<link rel="alternate" type="application/rss+xml" title="RSS"
        href="/rssfeed.xml" /> -->
   <link href="http://feeds2.feedburner.com/http/wwwgranbyrotaryorg"
        title="Subscribe to my feed" rel="alternate"
         type="application/rss+xml" />
   
   <!-- Link our custom CSS -->
   <link rel="stylesheet" title="Rotary Style Sheet"
        href="/css/rotary.css" type="text/css"/>

   <!-- CSS for News Rotator -->
   <link rel="stylesheet" href="/css/rotator.css" type="text/css"/>

   <!-- jQuery -->
   <script type="text/javascript" src="/js/jquery-1.3.2.min.js"></script>
   
   <!-- Drop down menues -->
<!--   <script type="text/javascript" src="/js/dropdown.js"></script>
   -->

   <!-- News Rotator -->
   <script type="text/javascript" src="/js/rotator.js"></script>

   <script type="text/javascript">
//jQuery.noConflict();

jQuery(document).ready(function($) {
  $("#child").hide();
  
  $("#parent").toggle(function() {
    $("#child").show();
  }, function() {
    $("#child").hide();
  });

  var oldfontsize = $("body").css("font-size");

  var p = .95;
  var wid = 580;
  
  if($("html").outerWidth() < wid) {
    var www = $("html").outerWidth();
    $("body").css("font-size", "8px");
    $("#navMap").css("width", www * p + "px");
  }

  // Change stuff to work on windows smaller than 800px
  
  $(window).resize(function() {
    var w = $("html").outerWidth();
    var ww = screen.width;
    if(ww < wid) {
      $("body").css("font-size", "8px");
    } else {
      if(w < wid) {
        $("body").css("font-size", "8px");
        $("#navMap").css("width", w * p + "px");
      } else {
        $("body").css("font-size", oldfontsize);
        $("#navMap").css("width", "");
      }
    }
          
  });
  
});
   </script>
   
   <!-- styles for this page only -->
   <style type="text/css">
#loginMsg {
        text-align: center;
}
#loginMsg a {
        font-variant: small-caps;
        font-size: x-large;
}

#wrapper {
        float: right;
        width: 50%;
        border: 1px solid white;
        margin-right: 10px;
}

/* link buttons */
#linkbuttons {
        border: 0;
/*        width: 280px; */
        width: 30%;
        margin-top: 30px;
        margin-bottom: 30px;
}

/* class button is also in rotary.css so check there too if thing change */
.button {
        border: 4px outset gray; 
        text-align: center;
        background-color: red;
        color: white;
        cursor: pointer;
}
.button a {
        color: white;
}

/* style for drop down */
#rotarylinks  {
        border: 0;
        width: 25%;
        margin-left: auto;
        margin-right: auto;
        margin-top: 30px;
        margin-bottom: 30px;
}
#parent {
        cursor: pointer;
        margin: 0;
}
#child {
        display: inline;
}
#child a {
        border: 1px solid black;
        display: block;
        padding: 2px 5px;
        background-color: white; /* #FFFFEE; */
}

/* Whos Been Here */
#todayGuests, #todayGuests * {
        background-color: white;
        border: 1px solid black;
}
#todayGuests * {
        padding: 5px;
}
   </style>

</head>

<body>

<?php
$gr->header("
      <p>PO Box 1430<br/>
      Granby, CO 80446<br/>
      e-mail:
      <a href='mailto:info@granbyrotary.org'>info@granbyrotary.org</a><br/>

      Meets Wednesday 12:00 PM at<br/>
      The Creekside Grill in The Silvercreek Inn<br/>
      62927 Highway 40<br/>
      Across from City Market off Highway 40<br/>
      Granby, CO<br/>
      <a href='/about.php#MapToMeetingPlace'>Map</a>
      </p>
      <a name='callin'></a>
");

// Check if a member  

if($gr->id != 0) {
  // MEMBER

  echo <<<EOF
<h3 id='loginMsg'>Welcome $gr->GrUser.</h3>
<p>If you are <b>not</b> a regular lunch meeting attendee or if you are going to bring extra guests
please let us know so we can plan for extra seating and food. If you <b>are</b> a regular lunch attendee
and you will not be able to attend please let us know also.
Please contact <a href='/email.php?id=29&amp;subject=Attend+Meeting'>Toni Russell</a>
at 970-557-4047 or click her name to send an email. Please try to call or email before 9 AM on Wednesday.
Members will not be charged for lunch if they do not attend. Also, members can attend the lunch meeting
and not eat lunch. You will not be charged if you do not eat.
</p>
<p>If you can't attend a meeting you could use the <a href="http://www.rotaryeclubone.org/">District's E-Club</a>
to make up a meeting ON-LINE. The web site <a href="http://www.rotaryeclubone.org/">www.rotaryeclubone.org</a> is
available 24/7. Learn more about
<a href="http://www.rotary.org/en/Members/GeneralInformation/PilotClubsAndE-clubs/Pages/ridefault.aspx">
E-Clubs</a>. Make-up's can be sent to info@granbyrotary.org, just fill this in on the on-line form at the above site.</p>

<p>Our club has raised \$1,737 for End Polio Champaign thus far this year. Our goal is \$100 per member which
should be about \$2,800 by the end of our fiscal year. Please visit the District End Polio web site at
<a href="http://www.endpolio.com?id=$gr->GrDistrictId">www.endpolio.com</a> and invite friends to become involved.</p>

<p style='color: red; background-color: white; padding: 5px'>Please look at the &quot;Meetings&quot; page as the <a href="meetings.php">Meeting Talk Roster Has Been Updated</a>.
 Our <b>Business Meetings</b> will now be on the first Wednesday of the Month right after the Board Meetings.
The Meeting list has been updated to reflect this change. Please look at the new list and <b>PLEASE</b> take note of
the date you are scheduled to present or have a presenter! Having this information in a timely manner makes life much
easier for your President and Board. Thank You</p>

<h2 style="color: red">Next Meeting Jan. 6 at Maverick's</h2>
<p>Starting Jan. 6 our Wed. lunch meetings will be held at Maverick's in Granby.</p>

<hr/>

EOF;
} else {
  // NOT A MEMBER OF NOT LOGGED IN
  echo <<<EOF
<h3 id='loginMsg'>If you are a Grand County Rotarian please
<a href='/login.php?return=$_SERVER[PHP_SELF]'>Login</a> at this time.<br/>
There is a lot more to see if you <a href='/login.php?return=$_SERVER[PHP_SELF]'>Login</a>!
</h3>
<p style='text-align: center'>Not a Grand County Rotarian? You can <b>Register</b> as a visitor.
<a href="/login.php?return=$_SERVER[PHP_SELF]&amp;visitor=1">Register</a></p>
<hr/>

EOF;
}
?>

<p>The Rotary Club of Granby was chartered in 1987, and its membership includes men and women representing a wide cross-section of
local businesses and professions. The club meets each Wednesday for fellowship, lunch, and interesting and informative programs
dealing with topics of local and global importance.  </p>

<p>The club is part of Rotary District 5450, comprised of 51 clubs and over 3,000 members. The 2009-2010 Rotary District Governor
is <a href="http://www.rotary5450.org">Mike Oldham</a>.  </p>

<table>
   <tr>
      <td style="width: 20%"><a href="http://www.endpolio.com?id=<?php echo $gr->GrDistrictId; ?>"><img
      src="images/endpolionow.jpg" alt="End Polio logo" style="width: 100%" /></a></td>
      <td style="padding: 10px">District 5450 is dedicated to the Rotary International's <span style="color: red; font-size: 150%;">End Polio
         Now</span> campaign. The District <a href="http://www.endpolio.com?id=<?php echo $gr->GrDistrictId; ?>">End Polio</a>
         web site <a href="http://www.endpolio.com?id=<?php echo $gr->GrDistrictId; ?>">www.endpolio.com</a>
         gives you a change to donate and to
         <a href="http://www.endpolio.com/endpolio/site/invitefriends.php?id=<?php echo $gr->GrDistrictId; ?>">Invite
            Friends</a>.  If each member asks ten friends to donate just $10 we will be able to meet our club's
         goal of raising $100 per member.
      </td>
   </tr>
</table>

<hr/>

<p style="margin-top: 10px;"><a href="/newsletters/latest.php">Latest Granby Rotary News
   Letter</a></p>

<div style="float: left">
<a href="http://www.facebook.com/group.php?gid=105501794053"><img
   src="/images/find_us_on_facebook_badge.gif"
   alt="find us on facebook" /></a>
</div>

<div style="float: right; width: 50%; margin-bottom: 10px; margin-right: 5px">
<?php
// Who has visited the home page today

$gr->WhosBeenHereToday();
?>
</div>

<br style="clear: both"/>

<!-- News Feed -->
<div id="wrapper">
   <p  style="padding: 0 5px">
   <a href="/about.php#rotaryint">Rotary International News
      Feed</a></p>
   <hr/>
   <h4 style="padding: 0 5px;">Highlights from our <a href="/news.php">News Page</a></h4>
   <p style="padding: 0 5px;">Move the mouse over the story to stop it from scrolling.</p>

   <div id="news-feed">
      <a href="/news.php">News Releases</a>
   </div>
</div>

<!-- News Changed? and Bulletin Board Buttons and rotary links -->
<div id='linkbuttons'>

<?php
// Has the News page changed since member was last here?

if($gr->newsChanged()) {
  echo <<<EOF
<p class='button' onclick='location.href="/news.php";'>
<img src='/images/new.gif' alt='New' /><a href='/news.php'>Breaking News</a><br/>
<span style='font-size: 12pt; color: black;'>Since You Last Looked</span>
</p>

EOF;
}

// Has the member seen all the BB posts?

// Use the new.gif image as a way to put the user's id into the log
// files.

if($NewBBmsg) {
  echo <<<EOF
<p class='button' onclick='location.href="/bboard.php";'>

<a href='/bboard.php'>Bulletin Board $NewBBmsg</a>
</p>
EOF;
} else {
  echo <<<EOF
<p class='button' onclick='location.href="/bboard.php";'>

<a href='/bboard.php'>Bulletin Board</a>
</p>
EOF;
}
?>

<!-- Rotary Links -->
      
<p id='parent' class='button'>Links to Rotary Sites</p>

<div id='child'>
   <a  href="http://rotary5450.org/">District 5450 Web Site</a>
   <a  href="http://www.rotary.org/">Rotary International Web Site</a>
   <a  href="http://www.endpolio.com">District 5450 End Polio
      Campaign</a>
   <a  href='http://rmryla.org'>RYLA (Rotary Youth Leadership Award)</a>
   <a  href='http://WinterparkFraserRotary.org'>Winter Park Rotary Club</a>
   <a  href='http://www.grandlakerotary.org/'>Grand Lake Rotary Club</a>
   <a  href='http://www.kremmlingrotary.org'>Kremmling Rotary Club</a>
   <a  href='http://escuelaminga.org/Minga/Rotary.html'>The Equator Project</a>
   <!--http://www.rotary5450.org/admin/Areas/Area17.htm Mark Kreig
   Assistent Governer for area 17 -->
</div>
</div>

<br style="clear: both" />
<hr/>
<!-- Footer. Setup Footer text -->
<?php

if($check->Unread && ($gr->id == ID_BARTON)) {
  // new mail in info@granbyrotary.org
  echo <<<EOF
<a href="/admin/ckemail.php">
<img src='/images/new.gif' alt='New Email Available'  style="border: 0"/>
</a> $check->Unread mail in info@granbyrotary.org <br\>

EOF;
}
   
$wc3val = <<<EOF

<p style='text-align: center;'><a href='/aboutwebsite.php'>About
   This Site</a></p>

<p style="text-align: center">
<a href="http://feeds2.feedburner.com/http/wwwgranbyrotaryorg"
title="Subscribe to my feed" rel="alternate"
type="application/rss+xml"><img
src="http://www.feedburner.com/fb/images/pub/feed-icon32x32.png"
alt="" style="border:0"/></a><a
href="http://feeds2.feedburner.com/http/wwwgranbyrotaryorg"
title="Subscribe to my feed" rel="alternate"
type="application/rss+xml">Subscribe in a reader</a>
<br/>
or<br/>
<a
href="http://feedburner.google.com/fb/a/mailverify?uri=http/wwwgranbyrotaryorg&amp;loc=en_US">Subscribe
to Granby Rotary Club by Email</a>

</p>

<!-- WC3 Validation for XHTML -->
<p style='text-align: center;'>
   <a href="http://validator.w3.org/check?uri=referer"><img
   src="/images/valid-xhtml10.png"
   alt="Valid XHTML 1.0 Strict"
   style='height: 31px; width: 88px; border: 0'/></a>

   <a href="http://jigsaw.w3.org/css-validator/check/referer">
      <img style="border:0;width:88px;height:31px"
             src="http://jigsaw.w3.org/css-validator/images/vcss"
             alt="Valid CSS!" />
   </a>
</p>

EOF;

$gr->footer($wc3val);
?>

<!-- All Done -->
</body>
</html>

