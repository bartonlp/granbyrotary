<?php
require_once("rotary.i.php");
$G = new GranbyRotary;
$self = $_SERVER['PHP_SELF'];
echo <<<EOF
<head>
  <title>Lunch Survey</title>
  <meta name="description"
     content="Name: Rotary Club of Granby Colorado, Page: Lunch Survey" />
  <meta name="keywords" content="rotary" />

   <!-- Link our custom CSS -->
   <link rel="stylesheet" title="Rotary Style Sheet"
        href="/css/rotary.css" type="text/css" />

   <script type='text/javascript'
            src='/js/jquery-1.3.2.min.js'></script>

   <!-- Inline Javascript if any -->
   <script type="text/javascript">
   </script>

   <!-- Inline CSS if any -->
   <style type='text/css'>
   </style>

</head>
<body>

EOF;

if(!$G->id) {
  echo <<<EOF
<h1>You Need To Log In</h1>
<p>Please <a href="login.php">LOG IN</a> then click on the email link again. Remember your login is your email address. Thank you.</p>
EOF;
  exit();
}

$G->header("<h2>Lunch Survey</h2>");
$vote = $_GET['vote'];
switch($vote) {
  case 'otherfilled':
    $vote = 'other';
    $other = $_GET['other'];
  case 'silvercreek':
  case 'mavericks':
  case 'dontcare':
    $G->query("insert into lunchsurvey (id, vote, other) value ('$G->id', '$vote', '$other') on duplicate key update vote='$vote', other='$other'");
    echo "<h1>Your Vote Has Been Tallied</h1>\n";
    break;  
  case 'other':
    echo <<<EOF
<h2>Select Your Preference</h2>
<form action="$self" method="get">
<table border="1">
<tr><td colspan="2"><input type="radio" name="vote" value="silvercreek">Silver Creek Inn</td></tr>
<tr><td colspan="2"><input type="radio" name="vote" value="mavericks">Maverick's</td></tr>
<tr><td colspan="2"><input type="radio" name="vote" value="dontcare">Don't Care</td></tr>
<tr>
<td><input type="radio" name="vote" value="otherfilled">Other</td>
<td><input type="text" name="other" /></td>
</tr>
<tr><td colspan="2"><input type="submit" name="submit" value="Submit Vote" /></td></tr>
</table>
</form>

EOF;
    break;

  default:
    echo "<h1>No Input</h1>";
    break;
}

echo <<<EOF
<a href="/">Go To Welcome Page</a>
</body>
</html>
EOF;

/*
The board of directors of The Granby Rotary Club would like your opinion. A while back we took a survey that asked you where you would like to have our luncheon meetings. At that time our members strongly favored "The Inn at Silver Creek" where we have been holding our meeting ever since.

We would like your opinion once again. Should we continue having our meeting at "The Inn at Silver Creek" or at some other location. We have contacted "Maverick's" and they would be willing to host our luncheons at the same cost as we are currently paying ($12). 

If we moved to another venue would you be more able to attend meetings?

To make this survey simple you can click on one of the following links to cast your vote. It that is too difficult please just reply to this email.

1) Continue to have our meetings at "The Inn at Silver Creek" http://www.granbyrotary.org/lunchsurvey.php?vote=silvercreek
2) Move our meetings to "Maverick's Restaurant" http://www.granbyrotary.org/lunchsurvey.php?vote=mavericks
3) I don't care, either place would be fine by me http://www.granbyrotary.org/lunchsurvey.php?vote=dontcare
4) I have another suggestion. You will be asked for the name of the other location when you reach the link http://www.granbyrotary.org/lunchsurvey.php?vote=other

You can change your vote as many times as you wish. The last vote counts.

Thank You
*/

?>

