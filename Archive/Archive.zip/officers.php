<?php
require_once("/home/bartonlp/includes/granbyrotary.conf");
$gr = new GranbyRotary;
?>
<head>
   <title>Club Officers and Directors</title>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
   <meta name="Author"
      content="Barton L. Phillips, mailto:barton@granbyrotary.org"/>
   <meta name="description"
      content="Name: Rotary Club of Granby Colorado, Page: Club Officers
         and Directors"/>
   <meta name="keywords" content="rotary"/>

   <!-- Link our custom CSS -->
   <link rel="stylesheet" title="Rotary Style Sheet"
        href="/css/rotary.css" type="text/css"/>

</head>

<body>
<?php
$gr->header("<h2>Club Officers and Directors<br/>2008 - 2009</h2>");
if($gr->id != 0) {
  print("
<h3 id='loginMsg'>Welcome $gr->GrUser.</h3>
<hr/>
");
} else {
  print("
<h3 id='loginMsg'>If you are a Granby Rotary Member please <a href='/login.php?return=$_SERVER[PHP_SELF]'>Login</a> at this time.<br/>
There is a lot more to see if you <a href='/login.php?return=$_SERVER[PHP_SELF]'>Login</a>!
</h3>
<hr/>
");
}
?>

<div class='blkcenter'>
<table style='background-color: white; text-align: left;' border='1' cellspacing="0" id="Sheet17Ctable">
   <tbody>
      <tr>
         <th>Position</th>
         <th>Name</th>
      </tr>
      <tr>
         <td>President</td>
         <td>Tim T Schowalter</td>
      </tr>
      <tr>
         <td>President Elect</td>
         <td>Jan Knisley</td>
      </tr>
      <tr>
         <td>Secretary</td>
         <td>Rhonda Farrell</td>
      </tr>
      <tr>
         <td>Treasurer</td>
         <td>Jack Bakken</td>
      </tr>
      <tr>
         <td>Club Newsletter Editor</td>
         <td>Patrick Brower</td>
      </tr>
      <tr>
         <td>Weekly Programs</td>
         <td>Barton Phillips</td>
      </tr>
      <tr>
         <td>Club Awards &amp; Recognition</td>
         <td>Jack Bakken</td>
      </tr>
      <tr>
         <td>Publicity Chair</td>
         <td>Patrick Brower</td>
      </tr>
      <tr>
         <td>Service Projects Chair</td>
         <td>Dorri Penny</td>
      </tr>
      <tr>
         <td>Community Service Chair</td>
         <td>Dorri Penny</td>
      </tr>
      <tr>
         <td>Literacy &amp; Education</td>
         <td>Jack Bakken</td>
      </tr>
      <tr>
         <td>Vocational Service  Chair</td>
         <td><i>OPEN</i> volunteers needed</td>
      </tr>
      <tr>
         <td>RYLA</td>
         <td>Barton Phillips</td>
      </tr>
      <tr>
         <td>Young RYLA</td>
         <td>Barton Phillips</td>
      </tr>
      <tr>
         <td>International Service</td>
         <td>Gary Perkins</td>
      </tr>
      <tr>
         <td>The Rotary Foundation Chair</td>
         <td>Frank DeLay</td>
      </tr>
      <tr>
         <td>Group Study Exchange</td>
         <td>Monte Roberts</td>
      </tr>
      <tr>
         <td>Fund Raiser Chairman</td>
         <td>Tom Chaffin</td>
      </tr>
      <tr>
         <td>Fourth of July</td>
         <td>Bill Edelstein</td>
      </tr>
      <tr>
         <td>Veterns Pancake Breakf, Aug. 16</td>
         <td>Mark Krieg</td>
      </tr>
      <tr>
         <td>Granby Oct. Fest Breakfast, Oct. 4</td>
         <td>Tom Chaffin</td>
      </tr>
      <tr>
         <td>Service Projects Chair</td>
         <td>Dorri Penny</td>
      </tr>
      <tr>
         <td>Blood Drive</td>
         <td><i>OPEN</i> volunteers needed</td>
      </tr>
      <tr>
         <td>Boy Scouts</td>
         <td>Frank DeLay</td>
      </tr>
      <tr>
         <td>Dictionary- Third Grade</td>
         <td>Frank DeLay</td>
      </tr>
      <tr>
         <td>Dolly Parton Imagination Library</td>
         <td>Jack Bakken</td>
      </tr>
      <tr>
         <td>9Health Fair</td>
         <td>Dorri Penny &amp; Ray Jennings</td>
      </tr>
      <tr>
         <td>Road Clean Up</td>
         <td>Jeff Shaw</td>
      </tr>
      <tr>
         <td>Schlorship Review</td>
         <td>Dorri Penny</td>
      </tr>
      <tr>
         <td>City Park Project</td>
         <td>Patrick Brower</td>
      </tr>
      <tr>
         <td>Fellowship Chairman</td>
         <td>Mark Bujanovich</td>
      </tr>
      <tr>
         <td>Lunch Call-in</td>
         <td>Jeff Shaw</td>
      </tr>
   </tbody>
</table>
</div>

<hr/>

<?php
$wc3val = <<<EOF
<!-- WC3 Validation for XHTML -->
<p>
   <a href="http://validator.w3.org/check?uri=referer"><img
   src="/images/valid-xhtml10.png"
   alt="Valid XHTML 1.0 Strict"
   style='height: 31px; width: 88px; border: 0'/></a>

   <a href="http://jigsaw.w3.org/css-validator/check/referer">
      <img style="border:0;width:88px;height:31px"
             src="http://jigsaw.w3.org/css-validator/images/vcss"
             alt="Valid CSS!" />
   </a>
</p>

EOF;
$gr->footer($wc3val);
?>

</body>
</html>
