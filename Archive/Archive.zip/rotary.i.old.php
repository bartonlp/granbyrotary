<?php
// One header file with class
// This include file has the <?xml version, DOCTYPE type, and html
// xml header stuff. See the class constructor for more details. The
// PHP code creates the variable $XmlDoctype.
require_once("rotarydoctype.i.php");

// Defines for the 'status' field in rotarymembers
// This field is now an emun 'active', 'inactive', 'visitor',
// 'honorary' so these are not really needed any more
define(STATUS_ACTIVE, 1);
define(STATUS_INACTIVE, 2);
define(STATUS_VISITOR, 3);
define(STATUS_HONORARY, 4);
// BE CAREFUL this could change!!!
define(ID_BARTON, 25);  // define my database id

class GranbyRotary {
  private $GrDb = 0;

  // These should be private but I have too many references to them
  // as publics
  
  public $GrId = 0;
  public $GrUser;  // "$FName $LName" as one unit from database, or empty
  public $GrEmail; // $Email from database, or empty
  public $GrDistrictId = 0;
  //----------------------
  // Class Constructor
  // $dispdoctype: if true display the doc type, else skip. Default
  //   is true.
  // $doctype: the <?xml...?\><!DOCTYPE...> header. If blank then (the
  //  defrault) then use the $XmlDoctype that is created in the
  //  require_once("rotarydoctype.i.php") above!
  //  To include other types of xml-doctypes include a file like
  //  'rotarydoctype.i.php 
  // $count: if true count access, else skip. Default true.
  //
  // NOTE: above in the comment the xml does not have a \ after the
  // ? but without that the PHP parser see the '?'+'>' as an end of
  // php marker. OPS 
  //----------------------

  // I want to change this so we pass the document type as a code and
  // then this will display that type. For example: 'xhtml1-strict'
  // or 'html4-loose' etc. Some day.
  
  public function __construct($dispdoctype=true, $doctype='', $count=true) {
    global $XmlDoctype; // from 'rotarydoctype.i.php'

    if(empty($doctype)) {
      $doctype = $XmlDoctype;
    }

    if($dispdoctype) echo $doctype;

    // If count is false then do NOT count this access
    
    if($this->CheckId() && $count) {
      // Count member's access to pages
      // Only count members

      $agent = $_SERVER['HTTP_USER_AGENT'];
      $ip = $_SERVER['REMOTE_ADDR'];
      $filename = $_SERVER['PHP_SELF']; // get the name of the file

      // Inc. visits for member
      
      $this->query("update rotarymembers set visits=visits+1 where id='$this->id'");

      // create or update memberpagecnt
      
      $this->query("insert into memberpagecnt (page, id, ip, agent, count) values('$filename', '$this->id', '$ip', '$agent', 1)
         on duplicate key update count=count+1, ip='$ip', agent='$agent'");
    }
  }

  //-------------------
  // Database Functions
  //-------------------
  
  //----------------------------------------------------------
  // resourceId opendb(<host>, <user>, <password>, <database>)
  // Opens the database, returns the resourceId
  //----------------------------------------------------------
  
  private function opendb($host = 'localhost:3306', $user = '2844', $password = '7098653', $database = 'granbyrotarydotorg') {
    // Only do one open
    
    if($this->GrDb) {
      return $this->GrDb;
    }
                        
    $db = mysql_connect($host, $user, $password, true);

    if(!$db) {
      echo "'rotary.i.php' Can't connect to database\n";
      exit;
    }

    if(!mysql_select_db($database, $db)) {
      echo "'rotary.i.php' Can't select database\n";
      exit;
    }
    $this->GrDb = $db;
    return $db;
  }

  //-------------------------------
  // resultId query(<query string>)
  //  On error calls SqlError() which outputs error message.
  //   On error function exits.
  //  returns resultId
  //-------------------------------
  
  public function query($query) {
    $db = $this->opendb();
    
    $result = mysql_query($query, $db);

    if(!$result) {
      SqlError(mysql_error($db), $query);
      exit();
    }
    return $result;
  }

  //--------------------------------
  // resourceId getDb()
  // returns the database resourceId
  // NOTE there is no setDb()!
  //--------------------------------
  
  public function getDb() {
    return $this->GrDb;
  }
  
  //-------------------
  // void SetIdCookie(<user id>)
  // Sets the browser Cookie to user ID
  //-------------------
  
  public function SetIdCookie($id) {
    $this->id = $id;
    $expire = time() + 31536000;  // one year from now

    $ref = ".granbyrotary.org";

    setcookie("GrId", $id, $expire, "/", $ref);
  }

  //----------------------------------------------------------------
  // int GetId(), string GetUser(), string GetEmail()
  // SetId(<user ID.), SetUser(<user name>), SetEmail(<email address>)
  // These functions are in case I ever want to make GrId, GrEmail,
  // and GrUser private.
  //----------------------------------------------------------------
  
  public function GetId() {
    return $this->id;
  }

  public function GetUser() {
    return $this->GrUser;
  }

  public function GetEmail() {
    return $this->GrEmail;
  }
  
  public function SetId($id) {
    $this->id = $id;
  }

  // 'user' is first and last name seperated by a space
  
  public function SetUser($user) {
    $this->GrUser = $user;
  }

  public function SetEmail($email) {
    $this->GrEmail = $email;
  }

  //--------------------------
  // int CheckId() private
  // Called by the constructor
  // returns the user ID or 0
  //--------------------------
  
  private function CheckId() {
    $id = $_COOKIE['GrId'];

    if(!isset($id)) {
      return 0;
    }

    $result = $this->query("select FName, LName, Email, districtId from rotarymembers where id='$id'");

    if(mysql_num_rows($result) == 0) {
       // OPS DIDN'T FIND THE ID IN THE DATABASE?

      return 0;
    }

    $row = mysql_fetch_row($result);

    $this->GrUser = "$row[0] $row[1]";

    $this->GrEmail = $row[2];

    $this->GrDistrictId = $row[3];
    
    // check the database to see if fastconnect is not null. 
    // if not null is it "y"? set to true of false.

    $this->id = $id;
    return $id;
  }

  //----------------------------
  // int CheckAndSetId()
  // returns the user ID or zero
  //----------------------------
  
  public function CheckAndSetId() {
    $id = $this->CheckId(); 

    if($id)
      setidcookie($id);

    return $id;
  }

  //--------------------------------------------------------------
  // string CheckUser()
  // returns a string that is either blank or has then number new
  // bulletin board entries. 
  //---------------------------------------------------------------
  
  public function CheckUser() {
    $msg = "";

    $id = $this->GetId();

    if($id) {
      $result = $this->query("select count(item) from bboard");  // count all items in bboard

      $row = mysql_fetch_row($result);

      $bbcount = $row[0]; // total items in bb

      $result = $this->query("select count(item) from bbsreadmsg where id='$id'"); // now count the number of items that I have read

      $row = mysql_fetch_row($result);

      $bbsreadcnt = $row[0]; // items that I have read

      // If there are some items in the bb

      if($bbcount) {
        // subtract the total from what I have read, this is the number
        // of UN read items.

        $cnt = $bbcount - $bbsreadcnt;

        // If ther are any unread items

        if($cnt) {
          $msg = "<br/>$cnt New Post" . ($cnt == 1 ? "" : "s");
        }
      }
    }
    return $msg;
  } 

  //-------------------
  // void feedCount()
  // used by rssfeed.php
  //-------------------
  
  public function feedCount() {
    $agent=$_SERVER[HTTP_USER_AGENT];
    $result = $this->query("insert into feedcnt (agent, count) values('$agent', 1) on duplicate key update count=count+1");
  }
  
  //-------------------
  // void counter(<counter message>)
  // Page Counter Function
  // Outputs the page counter text (this is no getCounter())
  //-------------------
  
  private function counter($msg='Number of Hits') {
    $filename = $_SERVER['PHP_SELF']; // get the name of the file

    $result = $this->query("select count from counter where filename='$filename'");

    if(mysql_num_rows($result) == 0) {
      // Not in database yet so create an entry for this file

      $this->query("insert into counter (filename, count) values('$filename', '1')");
      $count = 1;
    } else {
      $row = mysql_fetch_row($result);
      $count = $row[0]; // count

      // If this is user Barton Phillips don't count anything!

      if($this->id != ID_BARTON) {
        ++$count;
    
        $this->query("update counter set count='$count' where filename='$filename'");
      }
    }
    // The ctrnumber.php returns an image. The possible arguments are:
    // s=font size. if not pressent defaults to 11
    // text=the message which is usually a number like 11 etc. If not
    // pressent then blank.
    // font=font file, like TIMES.TTF. If not pressent defaults to
    // TIMESBD.TTF
    // rgb=the background color in rgb form like 233,255,100 etc. If not
    // pressent defaults to rgb=245,222,179 which is hex=#F5DEB3

    // the id's hitCounter, hitCounterp, hitCountertbl, hitCountertr,
    // hitCounterth, and ctrnumbers are defined in rotary.css

    echo <<<EOF
<div id='hitCounter'>
   $msg
      <table id='hitCountertbl'>
         <tr id='hitCountertr'>
            <th id='hitCounterth'><img id='ctrnumbers' src='/ctrnumbers.php?s=16&amp;text=$count' alt='$count'/></th>
         </tr>
      </table>
</div>

EOF;
  }

  //-------------------------
  // string getLastmod(<file name>)
  // Last Modified for a file
  // return the sql datetime string
  //-------------------------

  // Returns the date in mysql datetime format
  
  private function getLastmod() {
    // The club is in Colorado but the server is San Diego

    $row = mysql_fetch_assoc($this->query("select max(lasttime) as date from articles"));
    
    return $row['date'];    
  }

  //------------------------------------------------------------
  // boolian newsChanged()
  // Check if News page has changed since the last time the user
  // looked. Returns false if not changed. True if changed.
  // If true also updates members lastnews fieled in database
  //------------------------------------------------------------

  public function newsChanged() {
    $d = $this->getLastmod();
    $result = $this->query("select lastnews from rotarymembers where id=$this->id");

    $row = mysql_fetch_assoc($result);
    $lastnews = $row['lastnews'];

    //echo "d=$d, lastnews=$lastnews<br>";
    //echo "d=" . strtotime($d) . " lastnews=" . strtotime($lastnews) . "<br>";

    if(strtotime($d) > strtotime($lastnews)) {
      return true;
    }
    return false;
  }

  //------------------------------------------------------------------
  // void lookedAtNews()
  // in /news.php everytime a user accesses the page we update the
  // 'lastnews' field in the rotarymembers table. This lets us show a
  // message in /index.php when there is new news for a member to
  // look at.
  //------------------------------------------------------------------
  
  public function lookedAtNews() {
    // update members lastnews
    date_default_timezone_set('America/Denver');
    $date = date("Y-m-d H:i:s");
    $this->query("update rotarymembers set lastnews='$date' where id='$this->id'");
  }

  //------------------
  // Footer Functions
  //------------------
  
  //-----------------
  // string getFooter(<message>, <message to send to counter()>)
  //  returns the footer message as a string.
  //-----------------

  // Returns the header as a string
  
  public function getFooter($wc3val='', $msg='', $ctrMsg='') {
    ob_start();
    if($msg) {
      print("<div id='footerMsg'>$msg</div>\n");
    }

    if($ctrMsg) {
      $this->counter($ctrMsg);
    } else {
      $this->counter(); // Display counter
    }
    
    // The club is in Colorado but the server is San Diego
    
    date_default_timezone_set('America/Denver');
    $rdate = getlastmod();
    $date = date("M d, Y H:i:s", $rdate);

    $x = new DateTime($date);
    $off = $x->getOffset();

    $daylite = $off == -21600 ? "MDT" : "MST"; // 21600 min = 6 hr

    print("<p id='lastmodified'>Last Modified&nbsp;$date $daylite</p>");
    print("<p id='contactUs'><a href='mailto:info@granbyrotary.org'>Contact Us</a></p>\n");

    // validation if pressent
    if(!empty($wc3val)) {
      print($wc3val);
    }
    
    // Google Analysis code
    echo <<<EOF
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-713599-2");
pageTracker._trackPageview();
} catch(err) {}</script>

EOF;

    $m = ob_get_contents();
    ob_end_clean();
    return $m;
  }

  //--------------------------------------------
  // void footer(<wc3 validation message>,<message>, <counter message>)
  // Prints out the header
  //--------------------------------------------
  
  public function footer($wc3val='', $msg='', $ctrMsg='') {
    print($this->getFooter($wc3val, $msg, $ctrMsg));
  }

  //------------------
  // Header Functions
  //------------------
  
  //------------------
  // string getHeader(<page title>,<main title>)
  //  returns the header as a string
  //------------------

  // Returns the Header as a string
  
  public function getHeader($pageTitle,
                            $mainTitle = "<img src='/images/wheel.gif' alt='Rotary Wheel'/>\n<h1>The Rotary Club of Granby</h1>\n")
  {
    $ret =  <<<EOF
<div id='navMap'>
   <ul>
      <li id='NMhome'>
         <a href='/index.php'>Home</a>
      </li>

      <li id='NMabout'>
         <a href='/about.php'>About&nbsp;Rotary</a>
      </li>

      <li id='NMcalendar'>
         <a href='/calendar.php'>Club Calendar</a>
      </li>
EOF;

   if(!$this->id) {
      $ret .= <<<EOF
      <li id='NMLogin'>
         <a href='/login.php'>Login</a>
      </li>
EOF;
   } else {
      $ret .= <<<EOF
      <li id='NMProfile'>
         <a href='/edituserinfo.php'>User Profile</a>
      </li>
EOF;
   }
   $ret .= <<<EOF
      <li id='NMmembers'>
         <a href='/member_directory.php'>Members</a>
      </li>

      <li id='NMhits'>
         <a href='/hits.php'>Web Stats</a>
      </li>

      <li id='NMnews'>
         <a href='/news.php'>News</a>
      </li>

      <li id='NMmeetings'>
         <a
          href='/meetings.php'>Meetings</a>
      </li>
   </ul>
   <br/>
</div>
<div id='pagetitle'>
$mainTitle
$pageTitle
</div>

<noscript>
<p style='color: red; background-color: #FFE4E1; padding: 10px'>Your browser either does not support <b>JavaScripts</b> or you have JavaScripts disabled, in either case your browsing
experience will be significantly impaired. If your browser supports JavaScripts but you have it disabled consider enabaling
JavaScripts conditionally if your browser supports that. Sorry for the inconvienence.
</noscript>

EOF;

// WARNING About MSIE!

preg_match('/(MSIE.*?);/', $_SERVER[HTTP_USER_AGENT], $ar);
$msie = $ar[1];

$ret .= <<<EOF
<!--[if IE]>
<hr>
<p style='color: red'>You are running a version of Internet Explorer ($msie).
Unfortunatly IE is not very standards compliant.
There are several fratures that may not work correctly on this page depending on the
version of Internet Explorer you are using.
This page has been tested with
<a href='http://www.getfirefox.com'>Firefox</a>,
<a href='http://www.google.com/chrome'>Chrome</a>,
<a href='http://www.opera.com'>Opera</a>,
<a href='http://galeon.sourceforge.net/download/'>Galeon</a>, and
<a href='http://www.apple.com/safari/download/'>Safari</a>
and works well.
For best results download either Firefox or Chrome. I highly recomend changing your
browser to one of the standard complient browsers.</p>
<![endif]-->
<!--[if IE 8]>
<p>This site has been tested with IE 8 and appears to work correctly at this time, however; as new features are
added I may not be able to continue to make everything work with IE. Sorry.</p>
<![endif]-->
<!--[if lte IE 6]>
<span style='color: white; background-color: red'>Really any Internet Explorer less then version 7 just does not work!
If you must use IE please upgrade to 7 or above.</span>
<![endif]-->

<hr/>

EOF;
   return $ret;
  }

  //---------------------------------------
  // void header(<page title>,<main title>)
  // Outputs the header
  //---------------------------------------

  public function header($pageTitle,
                         $mainTitle = "<img src='/images/wheel.gif' alt='Rotary Wheel'/>\n<h1>The Rotary Club of Granby</h1>\n") {
      print($this->getHeader($pageTitle, $mainTitle));
  }

  //------------------------------
  // string getWhosBeenHereToday()
  //  returns string
  //------------------------------

  public function getWhosBeenHereToday() {
    ob_start();
    echo <<<EOF
<table id="todayGuests" style="width: 100%;">
<tbody>
<tr>
<th style="width: 60%">Who's visited our Home Page today?</th>
<th>Last Time</th>
</tr>

EOF;

  // NOTE the database last field has the San Diego time not our
  // time. So use ADDTIME to add one hour to the time to get Mountain
  // time.

  $result = $this->query("select concat(FName, ' ', LName) as name, date_format(addtime(last, '1:0'), '%H:%i:%s') as last from rotarymembers where id != 0 and visits != 0 and last > current_date() order by last desc");

  while($row = mysql_fetch_assoc($result)) {
    echo "<tr><td>" . stripslashes($row['name']) . "</td><td>$row[last]</td></tr>\n";
  }

  echo <<<EOF
</tbody>
</table>

EOF;
    $ret = ob_get_contents();
    ob_end_clean();
    return $ret;
  }
  
  //-----------------------------------------------
  // void whosBeenHereToday()
  // Display table showing who has been here today
  //-----------------------------------------------

  public function whosBeenHereToday() {
    echo $this->getWhosBeenHereToday();
  }

  //------------------------
  // void loginInfo()
  // Login Info Functioin
  // This is only used by the login.php
  // when members first login.
  //-----------------------------------

  public function loginInfo() {
    // Get the information we want to use

    $agent = $_SERVER['HTTP_USER_AGENT'];
    $ip = $_SERVER['REMOTE_ADDR'];

    //echo "ip=$ip, agent=$agent, id=$gr->id<br/>";

    // save IP, ID info

    $this->query("insert into logip (ip, count, id) values('$ip', '1', '$this->id')
    on duplicate key update count=count+1, id=$this->id");

    // save IP, AGENT, ID info

    $this->query("insert into logagent (ip, agent, count, id) values('$ip', '$agent', '1', '$this->id')
    on duplicate key update count=count+1, id='$this->id'");

    // Now update the users visit counter

    $this->query("update rotarymembers set visits=visits+1 where id='$this->id'");
  }
}

// End of class GranbyRotary

// Currently the two exception classes are NOT used (3/30/2009

//-------------------
// GrException class
//-------------------

class GrException extends Exception {
  // message, code. file, and line are members of Exception
  
  public function __construct($message, $code=-1) {
    parent::__construct($message, $code);
  }

  public function __toString() {
    // See if we have set_error_handler() set which catches PHP
    // errors and looks to see if the text says mysql. Then it adds
    // CAUGHT and throws a DbExeption.

    return __CLASS__ . "{ [FILE=$this->file] [LINE=$this->line] [Error='$this->message'] }";
  }
}

//--------------------
// SqlException class
//--------------------

class SqlException extends Exception {
  // message, code. file, and line are members of Exception
  
  public function __construct($message, $code=-1) {
    parent::__construct($message, $code);
  }

  public function __toString() {
    // See if we have set_error_handler() set which catches PHP
    // errors and looks to see if the text says mysql. Then it adds
    // CAUGHT and throws a DbExeption.

    return __CLASS__ . "{ [FILE=$this->file] [LINE=$this->line] [Error='$this->message'] }";
  }
}

//-----------------
// Database errors
// Simple function not an exception
//-----------------

if(!function_exists(SqlError)) {
  function SqlError($msg, $query) {
    $PHP_SELF = $_SERVER['PHP_SELF'];

    echo "<h1>SQL DEBUG INFO: ERROR in $PHP_SELF:</h1>\n";
    echo "<p>$msg</p>\n";
    echo "<p>Query: $query</p>\n";
//  mail("info@granbyrotary.org", "PhpError in $PHP_SELF", "Message:
//  $msg\nQuery=$query");  
  }
}

//------------------------------------------
// Helper function
// Function to strip slashes from $row array
//------------------------------------------

if(!function_exists(stripSlashesDeep)) {
  function stripSlashesDeep($value) {
    $value = is_array($value) ? array_map('stripSlashesDeep', $value) : stripslashes($value); 
    return $value;
  }
}

// WARNING THERE MUST BE NOTHING AFTER THE CLOSING PHP TAG.
// Really nothing not even a space!!!!
?>