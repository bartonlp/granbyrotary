<?php
require_once("/home/bartonlp/includes/granbyrotary.conf");

$S = new GranbyRotary;

// Check if a member  

if(!in_array($S->id, array(16, 25))) {
  echo "<h1>Sorry This Is Just For The President</h1>";
  exit();
}

$h->title = "President's Message";
$h->banner = "<h1>President's Message</h1>";
$top = $S->getPageTop($h);
$footer = $S->getFooter("<hr>");

if($_GET['post']) {
  extract($_GET);
  
  try {
    $query = "insert into presmsg (title, msg, date) values('$title', '$msg', now())";

    $S->query($query);
    $id = mysql_insert_id();
      
    if($id != 1) {
      $S->query("insert into presmsg (id, title, msg, date) values('1', '$title', '$msg', now())
on duplicate key update title='$title', msg='$msg', date=now()");
    }
  } catch(Exception $e) {
    if($e->getCode() == 1146) { // table does not exist
      $query2 = <<<EOF
CREATE TABLE `presmsg` (
  `id` int(11) NOT NULL auto_increment,
  `date` date,
  `title` text,
  `msg` text,
  `lasttime` timestamp,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
EOF;
      $S->query($query2);
      $S->query($query);
    } else {
      throw($e);
    }
  }

  echo <<<EOF
$top
<h1>Message Posted</h1>
$footer
EOF;
  exit();
}

// Preview page

if($_POST['submit']) {
  extract($_POST);
  $msg = stripslashes($msg);
  
  echo <<<EOF
$top
<div style="border: 1px solid black; background-color: white;">
<h1>$title</h1>
<p>$msg</p>
</div>
<p>If this is OK <a href="$S->self?post=1&title=$title&msg=$msg">Post It</a>, else go back and make corrections.</p>
$footer
EOF;
  exit();
}

echo <<<EOF
$top
<form action="$S->self" method="post">
<p>Enter Your message (or leave blank to remove message from Welcome Page).</p>
<input style="width: 95%" type="text" name="title" /><br>
<textarea name="msg" style="width: 95%; height: 200px"></textarea><br>
<input type="submit" name="submit" value="Submit" />
</form>
$footer
EOF;

?>  